"""
pos_adapters/factory.py
Returns the right POS adapter based on POS_ADAPTER setting in .env
"""

from pos_adapters.base import BasePOS
from config import settings


def get_pos_adapter() -> BasePOS:
    """
    Factory: returns configured POS adapter.
    Controlled by POS_ADAPTER in .env
    """
    adapter = settings.POS_ADAPTER.lower()

    if adapter == "square":
        from pos_adapters.square_pos import SquarePOS
        return SquarePOS()

    elif adapter == "custom":
        from pos_adapters.custom_pos import CustomRESTPos
        return CustomRESTPos()

    else:  # default: mock
        from pos_adapters.mock_pos import MockPOS
        return MockPOS()
