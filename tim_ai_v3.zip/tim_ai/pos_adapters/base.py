"""
pos_adapters/base.py
Abstract POS interface — all POS adapters implement this.

To add a new POS system:
1. Create a new file in pos_adapters/
2. Subclass BasePOS
3. Implement send_order() and check_availability()
4. Set POS_ADAPTER=your_adapter in .env
"""

from abc import ABC, abstractmethod
from typing import Optional


class BasePOS(ABC):
    """
    Every POS adapter must implement these two methods.
    """

    @abstractmethod
    def send_order(self, order_dict: dict) -> dict:
        """
        Send a confirmed order to the POS system.

        Args:
            order_dict: Order data from Order.to_dict()

        Returns:
            dict with at minimum:
                {
                    "success": True/False,
                    "pos_order_id": "<string or None>",
                    "message": "<human readable result>",
                    "raw_response": <whatever the POS returned>
                }
        """
        pass

    @abstractmethod
    def check_availability(self, item_name: str) -> bool:
        """
        Check if an item is currently available / in stock.

        Args:
            item_name: Canonical menu item name

        Returns:
            True if available, False if not
        """
        pass

    def get_wait_time(self) -> Optional[int]:
        """
        Optional: Return estimated wait time in minutes.
        Override if your POS supports this.
        """
        return None
