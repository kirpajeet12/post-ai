"""
config/settings.py
Centralised config — reads from .env or environment variables.
"""

import os
from dotenv import load_dotenv

load_dotenv()

# ── AI ────────────────────────────────────────
AI_PROVIDER: str = os.getenv("AI_PROVIDER", "mock")           # openai | anthropic | mock
OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "")
ANTHROPIC_API_KEY: str = os.getenv("ANTHROPIC_API_KEY", "")

# ── Twilio ────────────────────────────────────
TWILIO_ACCOUNT_SID: str = os.getenv("TWILIO_ACCOUNT_SID", "")
TWILIO_AUTH_TOKEN: str = os.getenv("TWILIO_AUTH_TOKEN", "")
TWILIO_PHONE_NUMBER: str = os.getenv("TWILIO_PHONE_NUMBER", "")

# ── POS ───────────────────────────────────────
POS_ADAPTER: str = os.getenv("POS_ADAPTER", "mock")           # mock | square | custom

SQUARE_ACCESS_TOKEN: str = os.getenv("SQUARE_ACCESS_TOKEN", "")
SQUARE_LOCATION_ID: str = os.getenv("SQUARE_LOCATION_ID", "")

CUSTOM_POS_BASE_URL: str = os.getenv("CUSTOM_POS_BASE_URL", "")
CUSTOM_POS_API_KEY: str = os.getenv("CUSTOM_POS_API_KEY", "")
CUSTOM_POS_ORDER_ENDPOINT: str = os.getenv("CUSTOM_POS_ORDER_ENDPOINT", "/api/orders")

# ── Server ────────────────────────────────────
PORT: int = int(os.getenv("PORT", 8000))
BASE_URL: str = os.getenv("BASE_URL", "http://localhost:8000")
