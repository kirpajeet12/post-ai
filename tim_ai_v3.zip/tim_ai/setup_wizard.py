#!/usr/bin/env python3
"""
setup_wizard.py
First-time setup for the AI ordering bot.
Saves config to .env and menu to menu_custom.json
Run once: python setup_wizard.py
Then run: python bot.py
"""

import os
import json
import sys

CONFIG_FILE = ".env"
MENU_FILE   = "menu_custom.json"

BANNER = """
╔═══════════════════════════════════════════════════════════════╗
║           AI ORDERING BOT — FIRST TIME SETUP                 ║
║   Works for any restaurant, cafe, shop, or business           ║
╚═══════════════════════════════════════════════════════════════╝
"""

def c(text, color):
    codes = {"green": "\033[92m", "yellow": "\033[93m", "red": "\033[91m",
             "cyan": "\033[96m", "bold": "\033[1m", "reset": "\033[0m", "dim": "\033[2m"}
    return f"{codes.get(color,'')}{text}{codes['reset']}"

def ask(prompt, default=None, secret=False):
    if default:
        display = f"{prompt} [{c(default, 'dim')}]: "
    else:
        display = f"{prompt}: "
    print(c("  → ", "cyan"), end="")
    if secret:
        import getpass
        val = getpass.getpass(display)
    else:
        val = input(display).strip()
    return val if val else default

def ask_choice(prompt, choices):
    print(c(f"\n  {prompt}", "yellow"))
    for i, ch in enumerate(choices, 1):
        print(f"    {c(str(i), 'cyan')}. {ch}")
    while True:
        val = input(c("  → Choice: ", "cyan")).strip()
        if val.isdigit() and 1 <= int(val) <= len(choices):
            return choices[int(val) - 1]
        print(c("  Please enter a number from the list.", "red"))

def section(title):
    print(f"\n{c('━'*60, 'cyan')}")
    print(c(f"  {title}", "bold"))
    print(c('━'*60, "cyan"))

def success(msg):
    print(c(f"\n  ✅  {msg}", "green"))

def warn(msg):
    print(c(f"\n  ⚠️   {msg}", "yellow"))

def load_existing_env():
    config = {}
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    config[k.strip()] = v.strip()
    return config


# ─────────────────────────────────────────────────────────────
# STEP 1 — Business Info
# ─────────────────────────────────────────────────────────────

def step_business_info(config):
    section("STEP 1 — Your Business")
    print(c("  This bot works for any business — restaurant, cafe, shop, etc.", "dim"))

    config["BUSINESS_NAME"]  = ask("Business name",    config.get("BUSINESS_NAME", "My Restaurant"))
    config["BUSINESS_TYPE"]  = ask_choice("Type of business", [
        "Restaurant", "Cafe / Coffee Shop", "Pizza Shop",
        "Food Truck", "Retail Store", "Other"
    ])
    config["GREETING_MSG"]   = ask(
        "Custom greeting (what AI says when someone calls/orders)",
        config.get("GREETING_MSG", f"Hi! Welcome to {config['BUSINESS_NAME']}. What can I get for you?")
    )
    return config


# ─────────────────────────────────────────────────────────────
# STEP 2 — AI Provider
# ─────────────────────────────────────────────────────────────

def step_ai_provider(config):
    section("STEP 2 — AI Provider")
    print(c("  The AI brain that understands customer orders.", "dim"))

    provider = ask_choice("Which AI do you want to use?", [
        "OpenAI (GPT-4o)  — recommended",
        "Anthropic (Claude) — alternative",
        "Mock / No AI  — rule-based only, FREE, no key needed",
    ])

    if "OpenAI" in provider:
        config["AI_PROVIDER"] = "openai"
        print(c("\n  Get your key at: https://platform.openai.com/api-keys", "dim"))
        key = ask("Paste your OpenAI API key (starts with sk-)", secret=True)
        if key:
            config["OPENAI_API_KEY"] = key
            success("OpenAI key saved.")
        else:
            warn("No key entered — falling back to mock mode.")
            config["AI_PROVIDER"] = "mock"

    elif "Anthropic" in provider:
        config["AI_PROVIDER"] = "anthropic"
        print(c("\n  Get your key at: https://console.anthropic.com", "dim"))
        key = ask("Paste your Anthropic API key (starts with sk-ant-)", secret=True)
        if key:
            config["ANTHROPIC_API_KEY"] = key
            success("Anthropic key saved.")
        else:
            warn("No key entered — falling back to mock mode.")
            config["AI_PROVIDER"] = "mock"

    else:
        config["AI_PROVIDER"] = "mock"
        success("Mock mode — no API key needed. AI uses rule-based matching.")

    return config


# ─────────────────────────────────────────────────────────────
# STEP 3 — POS System
# ─────────────────────────────────────────────────────────────

def step_pos(config):
    section("STEP 3 — POS System (Point of Sale)")
    print(c("  Where do orders go after the customer places them?", "dim"))

    pos = ask_choice("Which POS are you using?", [
        "None / Print to terminal (mock) — start here",
        "Square POS",
        "Custom REST API (any POS with an API)",
        "Skip for now",
    ])

    if "Square" in pos:
        config["POS_ADAPTER"] = "square"
        print(c("\n  Get keys at: https://developer.squareup.com", "dim"))
        config["SQUARE_ACCESS_TOKEN"] = ask("Square Access Token")
        config["SQUARE_LOCATION_ID"]  = ask("Square Location ID")
        success("Square POS configured.")

    elif "Custom" in pos:
        config["POS_ADAPTER"] = "custom"
        config["CUSTOM_POS_BASE_URL"]       = ask("POS API base URL (e.g. https://mypos.com)")
        config["CUSTOM_POS_API_KEY"]        = ask("POS API key", secret=True)
        config["CUSTOM_POS_ORDER_ENDPOINT"] = ask("Order endpoint", "/api/orders")
        success("Custom POS configured.")

    else:
        config["POS_ADAPTER"] = "mock"
        success("Mock POS — orders will print to terminal.")

    return config


# ─────────────────────────────────────────────────────────────
# STEP 4 — Menu Setup
# ─────────────────────────────────────────────────────────────

def step_menu(config):
    section("STEP 4 — Menu Setup")
    print(c("  What items does your business sell?", "dim"))

    choice = ask_choice("How do you want to set up your menu?", [
        "Type items in now (quick setup)",
        "Load from a JSON file on my computer",
        "Load from a CSV file on my computer",
        "Use the default Tim Hortons demo menu",
        "Skip — I'll edit menu_custom.json manually later",
    ])

    if "Type items" in choice:
        return step_menu_manual(config)
    elif "JSON" in choice:
        return step_menu_from_file(config, "json")
    elif "CSV" in choice:
        return step_menu_from_file(config, "csv")
    elif "Tim Hortons" in choice:
        config["MENU_FILE"] = "core/menu.py"
        success("Using built-in Tim Hortons demo menu.")
        return config
    else:
        config["MENU_FILE"] = MENU_FILE
        warn(f"Skipped. Edit {MENU_FILE} manually before running the bot.")
        # Create empty template
        save_menu({})
        return config


def step_menu_manual(config):
    """Type menu items one by one in the terminal."""
    print(c("\n  Add your menu items. Press Enter with no name to finish.\n", "dim"))

    menu = {}
    category = ask("First category name (e.g. Drinks, Food, Desserts)", "Drinks")

    while True:
        print(c(f"\n  [{category}] — Enter item name (or 'done' to finish, 'new category' for next section):", "yellow"))
        name = input(c("  → Item name: ", "cyan")).strip()

        if not name or name.lower() == "done":
            break

        if name.lower() == "new category":
            category = ask("New category name")
            continue

        price = ask(f"  Price for {name} (e.g. 2.99)", "0.00")
        sizes_input = ask(f"  Sizes for {name} (comma separated, or leave blank if no sizes)", "")
        sizes = [s.strip() for s in sizes_input.split(",")] if sizes_input else None
        mods_input = ask(f"  Modifiers/options for {name} (e.g. no sauce, extra cheese)", "")
        mods = [m.strip() for m in mods_input.split(",")] if mods_input else []

        # Build aliases from name
        aliases = [name.lower()]
        short = name.lower().split()[0]
        if short != name.lower():
            aliases.append(short)

        menu[name.lower()] = {
            "category": category.lower().replace(" ", "_"),
            "aliases": aliases,
            "sizes": sizes,
            "modifiers": mods,
            "base_price": float(price) if price else 0.0,
            "pos_item_id": name.upper().replace(" ", "_")[:20],
        }
        success(f"Added: {name}")

    if menu:
        save_menu(menu)
        config["MENU_FILE"] = MENU_FILE
        success(f"Menu saved to {MENU_FILE} with {len(menu)} items.")
    else:
        warn("No items added.")

    return config


def step_menu_from_file(config, fmt):
    """Load menu from a user-provided file path."""
    print(c(f"\n  Paste the full path to your {fmt.upper()} file:", "dim"))
    print(c("  Example: /home/user/my_menu.json  or  C:\\Users\\me\\menu.csv", "dim"))
    path = ask("File path")

    if not path or not os.path.exists(path):
        warn(f"File not found: {path}. Skipping menu setup.")
        config["MENU_FILE"] = MENU_FILE
        save_menu({})
        return config

    try:
        if fmt == "json":
            with open(path) as f:
                menu = json.load(f)
            save_menu(menu)
            success(f"Loaded {len(menu)} items from {path}")

        elif fmt == "csv":
            import csv
            menu = {}
            with open(path) as f:
                reader = csv.DictReader(f)
                for row in reader:
                    name = row.get("name", "").strip().lower()
                    if not name:
                        continue
                    menu[name] = {
                        "category": row.get("category", "general").lower(),
                        "aliases": [name],
                        "sizes": [s.strip() for s in row.get("sizes", "").split(",")] if row.get("sizes") else None,
                        "modifiers": [m.strip() for m in row.get("modifiers", "").split(",")] if row.get("modifiers") else [],
                        "base_price": float(row.get("price", 0)),
                        "pos_item_id": name.upper().replace(" ", "_")[:20],
                    }
            save_menu(menu)
            success(f"Loaded {len(menu)} items from CSV")

        config["MENU_FILE"] = MENU_FILE

    except Exception as e:
        warn(f"Could not read file: {e}")
        config["MENU_FILE"] = MENU_FILE
        save_menu({})

    return config


def save_menu(menu):
    with open(MENU_FILE, "w") as f:
        json.dump(menu, f, indent=2)


# ─────────────────────────────────────────────────────────────
# STEP 5 — Twilio (Optional)
# ─────────────────────────────────────────────────────────────

def step_twilio(config):
    section("STEP 5 — Phone Calls via Twilio (Optional)")
    print(c("  Skip this if you only want to use the terminal bot.", "dim"))

    use = ask_choice("Do you want to enable phone call support?", [
        "No — terminal only for now",
        "Yes — set up Twilio",
    ])

    if "Yes" in use:
        print(c("\n  Get credentials at: https://twilio.com/console", "dim"))
        config["TWILIO_ACCOUNT_SID"]  = ask("Twilio Account SID")
        config["TWILIO_AUTH_TOKEN"]   = ask("Twilio Auth Token", secret=True)
        config["TWILIO_PHONE_NUMBER"] = ask("Your Twilio phone number (e.g. +16041234567)")
        config["BASE_URL"]            = ask("Your public server URL (e.g. https://abc.ngrok.io)", "http://localhost:8000")
        success("Twilio configured. Run: python server.py")
    else:
        config["BASE_URL"] = "http://localhost:8000"
        success("Skipped. You can add Twilio later by re-running setup.")

    return config


# ─────────────────────────────────────────────────────────────
# SAVE CONFIG
# ─────────────────────────────────────────────────────────────

def save_config(config):
    lines = [
        "# AI Ordering Bot — Auto-generated config",
        "# Re-run: python setup_wizard.py to change settings\n",
    ]
    for k, v in config.items():
        lines.append(f"{k}={v}")
    with open(CONFIG_FILE, "w") as f:
        f.write("\n".join(lines))


# ─────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────

def main():
    print(BANNER)

    # Check if already configured
    existing = load_existing_env()
    if existing and existing.get("BUSINESS_NAME"):
        print(c(f"  Existing config found for: {existing.get('BUSINESS_NAME')}", "yellow"))
        choice = ask_choice("What do you want to do?", [
            "Reconfigure everything",
            "Just update the menu",
            "Just update API keys",
            "Exit",
        ])
        if "Exit" in choice:
            sys.exit(0)
        elif "menu" in choice.lower():
            config = existing
            config = step_menu(config)
            save_config(config)
            success("Menu updated! Run: python bot.py")
            return
        elif "keys" in choice.lower():
            config = existing
            config = step_ai_provider(config)
            save_config(config)
            success("Keys updated! Run: python bot.py")
            return

    config = existing.copy()

    # Run all setup steps
    config = step_business_info(config)
    config = step_ai_provider(config)
    config = step_pos(config)
    config = step_menu(config)
    config = step_twilio(config)

    # Save everything
    save_config(config)

    # Summary
    section("SETUP COMPLETE")
    print(f"""
  {c('Business:', 'bold')}  {config.get('BUSINESS_NAME')}
  {c('AI Mode:', 'bold')}   {config.get('AI_PROVIDER', 'mock')}
  {c('POS:', 'bold')}       {config.get('POS_ADAPTER', 'mock')}
  {c('Menu:', 'bold')}      {config.get('MENU_FILE', 'custom')}
  {c('Phone:', 'bold')}     {'Twilio enabled' if config.get('TWILIO_ACCOUNT_SID') else 'Terminal only'}
    """)

    print(c("  ▶  Run your bot:", "bold"))
    print(c("     python bot.py\n", "green"))

    if config.get("TWILIO_ACCOUNT_SID"):
        print(c("  ▶  Run phone server:", "bold"))
        print(c("     python server.py\n", "green"))

    print(c("  ▶  Re-run setup anytime:", "bold"))
    print(c("     python setup_wizard.py\n", "green"))


if __name__ == "__main__":
    main()
