"""
parser/parser.py
Converts raw user text → structured LineItem(s).

Two modes:
  1. Rule-based (no API key needed, works offline)
  2. LLM-assisted (more accurate, requires ai_engine)

Key functions:
  parse_text(text)     → Optional[LineItem]   (single item, backwards compat)
  parse_multiple(text) → List[LineItem]        (handles "X and Y" in one sentence)
"""

import re
from typing import Optional, List
from core.order import LineItem
from core.menu import get_all_aliases, get_item


# ─────────────────────────────────────────────
# CONSTANTS
# ─────────────────────────────────────────────

SIZE_WORDS = ["extra large", "large", "medium", "small"]
SIZE_ALIASES = {
    "xl": "extra large", "xlarge": "extra large",
    "sm": "small", "lg": "large", "md": "medium",
}

COFFEE_PRESETS = {
    "double double": "double double",
    "triple triple": "triple triple",
    "black": "black",
}

# Splits "X and Y", "X also Y", "X plus Y", "X, Y"
_SPLIT_PATTERN = re.compile(
    r"\band\b|\balso\b|\bplus\b|,\s*",
    re.IGNORECASE,
)


# ─────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────

def normalize(text: str) -> str:
    return re.sub(r"\s+", " ", text.strip().lower())


def detect_size(text: str) -> Optional[str]:
    t = normalize(text)
    for alias, canonical in SIZE_ALIASES.items():
        if re.search(rf"\b{alias}\b", t):
            return canonical
    for size in SIZE_WORDS:
        if size in t:
            return size
    return None


def detect_qty(text: str) -> int:
    t = normalize(text)
    if "half dozen" in t:
        return 6
    m = re.search(r"\b(\d+)\b", t)
    if m:
        return max(1, int(m.group(1)))
    word_map = {
        "a": 1, "an": 1, "one": 1, "two": 2, "three": 3,
        "four": 4, "five": 5, "six": 6, "dozen": 12,
    }
    for w, n in word_map.items():
        if re.search(rf"\b{w}\b", t):
            return n
    return 1


def detect_modifiers(text: str, item_name: str) -> list:
    """Extract modifiers that are relevant to this item."""
    t = normalize(text)
    mods = []
    item_data = get_item(item_name)
    if not item_data:
        return mods
    allowed = [m.lower() for m in item_data.get("modifiers", [])]

    # Coffee presets first (most specific)
    for phrase, mod in COFFEE_PRESETS.items():
        if phrase in t and mod in allowed:
            mods.append(mod)

    # Sugar count  e.g. "2 sugar"
    sugar_match = re.search(r"\b(\d)\s*sugar(s)?\b", t)
    if sugar_match:
        mod = f"{sugar_match.group(1)} sugar"
        if mod in allowed:
            mods.append(mod)

    # All other allowed modifiers
    for mod in allowed:
        if mod not in mods and mod in t:
            mods.append(mod)

    return mods


# ─────────────────────────────────────────────
# SINGLE ITEM PARSER
# ─────────────────────────────────────────────

def parse_single(text: str) -> Optional[LineItem]:
    """
    Parse ONE item from a chunk of text.
    Returns LineItem or None if nothing recognised.
    """
    t = normalize(text)

    # Find best-matching menu item (longest alias wins = most specific)
    aliases = get_all_aliases()
    matched_name = None
    for canonical, alias in aliases:
        if alias in t:
            matched_name = canonical
            break

    # "double double" / "triple triple" without the word "coffee" still means coffee
    if not matched_name:
        if any(p in t for p in ["double double", "triple triple"]):
            matched_name = "coffee"
        else:
            return None

    qty  = detect_qty(t)
    size = detect_size(t)
    mods = detect_modifiers(t, matched_name)

    # Default size to medium for beverages when caller didn't specify
    item_data = get_item(matched_name)
    if item_data and item_data.get("sizes") and not size:
        size = "medium"

    return LineItem(name=matched_name, qty=qty, size=size, modifiers=mods)


# ─────────────────────────────────────────────
# MULTI-ITEM PARSER  ← the main fix
# ─────────────────────────────────────────────

def parse_multiple(text: str) -> List[LineItem]:
    """
    Parse MULTIPLE items from one sentence.

    Examples:
      "1 double double and turkey bacon club with no sauce"
        → [coffee(medium, double double), turkey bacon club(no sauce)]

      "large iced capp, hash brown and bacon sandwich on biscuit"
        → [iced capp(large), hash brown, bacon breakfast sandwich(biscuit)]

    Strategy:
      1. Split on "and / also / plus / ,"
      2. Parse each chunk independently
      3. If split finds nothing, try the whole sentence as one item
    """
    t = normalize(text)
    chunks = _SPLIT_PATTERN.split(t)

    items = []
    for chunk in chunks:
        chunk = chunk.strip()
        if not chunk:
            continue
        item = parse_single(chunk)
        if item:
            items.append(item)

    # Fallback: no split worked — try the whole thing
    if not items:
        item = parse_single(t)
        if item:
            items.append(item)

    return items


# ─────────────────────────────────────────────
# BACKWARDS-COMPATIBLE SINGLE ENTRY POINT
# ─────────────────────────────────────────────

def parse_text(text: str) -> Optional[LineItem]:
    """
    Returns the first item found. Use parse_multiple() for multi-item sentences.
    Kept for backwards compatibility with telephony handler.
    """
    items = parse_multiple(text)
    return items[0] if items else None


# ─────────────────────────────────────────────
# LLM-ASSISTED PARSER
# ─────────────────────────────────────────────

PARSE_SYSTEM_PROMPT = """You are an order parsing assistant for a coffee shop.
Extract ALL items from the customer's message and return ONLY a valid JSON array.

JSON format — always an ARRAY even for one item:
[
  {
    "item": "<canonical item name>",
    "qty": <integer>,
    "size": "<small|medium|large|extra large|null>",
    "modifiers": ["<mod1>", "<mod2>"]
  }
]

Known items: {menu_items}

Rules:
- "double double" means 2 cream 2 sugar (modifier for coffee)
- If no size is stated for a drink, use "medium"
- Return null for size if item has no size option (e.g. hash brown)
- Return empty array [] for modifiers if none
- If you cannot identify ANY item, return: []
- Capture EVERY item the customer mentions, even if they say multiple things
"""


def parse_text_with_llm(text: str, ai_client) -> Optional[LineItem]:
    """
    LLM-assisted parser. Returns FIRST item (for backwards compat with telephony).
    Falls back to rule-based if LLM fails.
    """
    items = parse_multiple_with_llm(text, ai_client)
    return items[0] if items else None


def parse_multiple_with_llm(text: str, ai_client) -> List[LineItem]:
    """
    LLM-assisted multi-item parser.
    Falls back to rule-based parse_multiple() on any error.
    """
    import json
    from core.menu import MENU

    menu_items = ", ".join(MENU.keys())
    system = PARSE_SYSTEM_PROMPT.format(menu_items=menu_items)

    try:
        response = ai_client.complete(system=system, user=text, max_tokens=400)

        raw = response.strip()
        if raw.startswith("```"):
            raw = re.sub(r"```[a-zA-Z]*\n?", "", raw).strip("`").strip()

        data = json.loads(raw)
        if not isinstance(data, list):
            raise ValueError("Expected JSON array")

        items = []
        for entry in data:
            if not entry.get("item"):
                continue
            items.append(LineItem(
                name=entry["item"],
                qty=int(entry.get("qty", 1)),
                size=entry.get("size"),
                modifiers=entry.get("modifiers", []),
            ))
        return items if items else parse_multiple(text)

    except Exception:
        return parse_multiple(text)
