"""
core/engine.py  v3
Fixes:
  1. Size change requests ("no i want it small", "make it large") → update last item
  2. "no thats all" → contains done intent even with "no" prefix
  3. Confirmation state accepts corrections ("just 1 small double double")
"""

from enum import Enum
from typing import Optional, List
from core.order import Order, LineItem
from core.menu import get_item, is_available
import re


class ConversationState(str, Enum):
    GREETING      = "greeting"
    TAKING_ORDER  = "taking_order"
    UPSELL        = "upsell"
    CONFIRMATION  = "confirmation"
    COMPLETE      = "complete"
    CANCELLED     = "cancelled"


DONE_PHRASES = {
    "that's all", "thats all", "that is all", "done", "nothing else",
    "no thanks", "no thank you", "i'm good", "im good", "finish",
    "complete", "place order", "confirm", "that'll be all", "thatll be all",
}

CANCEL_PHRASES = {
    "cancel", "start over", "reset", "never mind", "nevermind",
}

YES_PHRASES = {"yes", "y", "yeah", "yep", "sure", "ok", "okay", "please", "yup", "yea", "ya"}
NO_PHRASES  = {"no", "n", "nope", "nah"}

SIZE_WORDS  = ["extra large", "large", "medium", "small"]

# Phrases that signal a size change request
SIZE_CHANGE_PATTERNS = [
    r"\b(make it|change it to|i want it|actually|i meant|can you make it)\b.*(small|medium|large|extra large)\b",
    r"\b(small|medium|large|extra large)\b.*(one|please|instead)\b",
    r"^(small|medium|large|extra large)$",
]


def _contains_done(text: str) -> bool:
    """Check if text CONTAINS a done phrase anywhere (not just exact match)."""
    t = text.strip().lower()
    # exact match first
    if t in DONE_PHRASES:
        return True
    # contains check — e.g. "no thats all", "ok thats all"
    for phrase in DONE_PHRASES:
        if phrase in t:
            return True
    return False


def _detect_size_change(text: str) -> Optional[str]:
    """
    Detect if the user is asking to change the size of the last item.
    Returns the new size string or None.
    Examples:
      "no i want it small"   → "small"
      "make it large"        → "large"
      "actually medium"      → "medium"
      "i want it small"      → "small"
    """
    t = text.strip().lower()

    for pattern in SIZE_CHANGE_PATTERNS:
        m = re.search(pattern, t)
        if m:
            # find the size word in the match
            for size in SIZE_WORDS:
                if size in t:
                    return size

    # Simple fallback: "i want it X" or "no X" where X is just a size
    for size in SIZE_WORDS:
        if re.search(rf"\b{size}\b", t):
            # Make sure it's clearly about size, not a new order
            size_intent_words = ["want it", "make it", "actually", "instead", "i said", "i mean", "change"]
            if any(w in t for w in size_intent_words):
                return size

    return None


class OrderEngine:

    def __init__(self):
        self.order  = Order()
        self.state  = ConversationState.GREETING
        self._pending_upsell: Optional[str] = None
        self._last_upsell_item: Optional[str] = None
        self._upsell_offered   = False   # prevent re-offering same upsell

    # ── Intent Detection ─────────────────────────────────

    def is_done(self, text: str) -> bool:
        return _contains_done(text)

    def is_cancel(self, text: str) -> bool:
        return text.strip().lower() in CANCEL_PHRASES

    def is_yes(self, text: str) -> bool:
        return text.strip().lower() in YES_PHRASES

    def is_no(self, text: str) -> bool:
        t = text.strip().lower()
        # Only pure "no" phrases — not "no i want it small" (that's a size change)
        return t in NO_PHRASES

    # ── Size Change ──────────────────────────────────────

    def try_size_change(self, text: str) -> Optional[str]:
        """
        If user is asking to change the size of the last item, update it.
        Returns response string if handled, None if not a size change.
        """
        new_size = _detect_size_change(text)
        if not new_size:
            return None

        if not self.order.items:
            return "I don't have any items in your order yet. What can I get you?"

        last = self.order.items[-1]
        item_data = get_item(last.name)

        # Check item actually has sizes
        if not item_data or not item_data.get("sizes"):
            return f"Sorry, {last.name} doesn't come in different sizes."

        if new_size not in item_data["sizes"]:
            available = ", ".join(item_data["sizes"])
            return f"Sorry, {last.name} only comes in: {available}."

        old_size = last.size
        last.size = new_size
        return f"Got it — changed your {last.name} from {old_size} to {new_size}. Anything else?"

    # ── Multi-Item Add ───────────────────────────────────

    def add_items(self, items: List[LineItem]) -> str:
        if not items:
            return "Sorry, I didn't catch any items. What can I get you?"
        if len(items) == 1:
            return self.add_item(items[0])

        added_names = []
        unavailable = []

        for item in items:
            if not is_available(item.name):
                unavailable.append(item.name)
                continue
            self.order.add_item(item)
            added_names.append(item.display())

        self.state = ConversationState.TAKING_ORDER
        self._upsell_offered = False

        response_parts = []
        if added_names:
            response_parts.append(f"Got it — {', '.join(added_names)}.")
        if unavailable:
            response_parts.append(f"Sorry, {', '.join(unavailable)} isn't available right now.")

        if self.order.items and not self._upsell_offered:
            upsell = self._check_upsell(self.order.items[-1])
            if upsell:
                self._pending_upsell = upsell
                self._upsell_offered = True
                self.state = ConversationState.UPSELL
                response_parts.append(upsell)
                return " ".join(response_parts)

        response_parts.append("Anything else for you?")
        return " ".join(response_parts)

    def add_item(self, item: LineItem) -> str:
        if not is_available(item.name):
            return f"Sorry, {item.name} isn't available right now. Can I get you something else?"

        self.order.add_item(item)
        self.state = ConversationState.TAKING_ORDER
        self._upsell_offered = False

        if not self._upsell_offered:
            upsell = self._check_upsell(item)
            if upsell:
                self._pending_upsell = upsell
                self._upsell_offered = True
                self.state = ConversationState.UPSELL
                return f"Got it — {item.display()}. {upsell}"

        return f"Got it — {item.display()}. Anything else for you?"

    # ── Upsell ───────────────────────────────────────────

    def handle_upsell_response(self, text: str, parsed_items: List[LineItem] = None) -> str:
        self._pending_upsell = None
        self.state = ConversationState.TAKING_ORDER

        if parsed_items:
            return self.add_items(parsed_items)

        if self.is_yes(text):
            if self._last_upsell_item:
                self.order.add_item(LineItem(name=self._last_upsell_item, qty=1))
                self._last_upsell_item = None
                return "Added. Anything else for you?"
            return "Sure! What would you like — medium coffee, iced capp, or something else?"

        return "No problem. Anything else for you?"

    # ── Confirmation ─────────────────────────────────────

    def confirm_order(self) -> str:
        self.state = ConversationState.CONFIRMATION
        if self.order.is_empty():
            self.state = ConversationState.TAKING_ORDER
            return "I don't have anything in your order yet. What can I get you?"

        summary = self.order.summary()
        return (
            f"Just to confirm, you have:\n{summary}\n\n"
            "Say 'yes' to place it, 'no' to change something, or just tell me what to fix."
        )

    def apply_correction(self, text: str, parsed_items: List[LineItem] = None) -> str:
        """
        Handle corrections during confirmation state.
        e.g. "just 1 small double double" → clear order, add corrected item
        """
        self.state = ConversationState.TAKING_ORDER

        # If they gave us a corrected item, replace the order
        if parsed_items:
            self.order.items.clear()
            return self.add_items(parsed_items)

        return "What would you like to change?"

    def finalize(self) -> Order:
        from core.order import OrderStatus
        self.order.status = OrderStatus.CONFIRMED
        self.state = ConversationState.COMPLETE
        return self.order

    def cancel(self) -> str:
        self.order = Order()
        self.state = ConversationState.GREETING
        return "Order cancelled. Let's start fresh — what can I get you?"

    # ── Upsell Rules ─────────────────────────────────────

    def _check_upsell(self, item: LineItem) -> Optional[str]:
        drink_categories = {"hot_beverages", "cold_beverages"}

        def has_drink():
            return any(
                get_item(i.name) and get_item(i.name).get("category") in drink_categories
                for i in self.order.items
            )

        def has_hash():
            return any(i.name == "hash brown" for i in self.order.items)

        breakfast_items = {
            "bacon breakfast sandwich",
            "sausage breakfast sandwich",
            "farmer's wrap",
        }

        if item.name in breakfast_items and not has_hash():
            self._last_upsell_item = "hash brown"
            return "Would you like to add a hash brown for $1.99?"

        item_data = get_item(item.name)
        item_cat = item_data.get("category") if item_data else None
        if item_cat not in drink_categories and not has_drink():
            return "Can I get you a drink with that? Medium coffee, iced capp, or anything else?"

        return None
