# TIM AI — Restaurant Voice Order Engine

Modular AI-powered ordering system with Twilio, LLM, and POS integration.

```
Phone Call → Twilio → AI Brain → Order Engine → POS Adapter → Kitchen
```

---

## 🏗 Architecture

```
tim_ai/
├── core/
│   ├── order.py          # Data models (LineItem, Order)
│   ├── menu.py           # Menu database
│   └── engine.py         # Order state machine
│
├── parser/
│   └── parser.py         # Text → structured order (rule-based + LLM)
│
├── ai_engine/
│   └── llm.py            # OpenAI / Claude AI conversation handler
│
├── telephony/
│   └── twilio_handler.py # Twilio call webhook handler
│
├── pos_adapters/
│   ├── base.py           # Abstract POS interface
│   ├── mock_pos.py       # Terminal mock (for testing)
│   ├── square_pos.py     # Square POS adapter
│   └── custom_pos.py     # Generic REST POS adapter
│
├── config/
│   └── settings.py       # Env vars / config
│
├── cli.py                # Terminal runner (no Twilio needed)
├── server.py             # FastAPI server (Twilio webhook)
└── requirements.txt
```

---

## 🚀 Quick Start (Terminal Mode)

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Copy and fill env vars
cp .env.example .env

# 3. Run terminal demo (no APIs needed)
python cli.py

# 4. Run with real AI (needs OPENAI_API_KEY in .env)
python cli.py --use-ai

# 5. Run Twilio webhook server
python server.py
```

---

## 🔌 POS Integration

To add your own POS, create a class in `pos_adapters/` that extends `BasePOS`:

```python
from pos_adapters.base import BasePOS

class MyPOS(BasePOS):
    def send_order(self, order_dict: dict) -> dict:
        # call your POS API here
        return {"status": "success", "order_id": "12345"}
    
    def check_item_availability(self, item_name: str) -> bool:
        # check inventory
        return True
```

Then swap it in `cli.py` or `server.py`:
```python
from pos_adapters.my_pos import MyPOS
pos = MyPOS()
```

---

## 📞 Twilio Setup

1. Get a Twilio number at twilio.com
2. Set webhook URL to: `https://your-server.com/voice`
3. Add credentials to `.env`
4. Deploy `server.py` to any server

---

## 🤖 AI Providers Supported

| Provider | Model | Set in .env |
|----------|-------|-------------|
| OpenAI   | gpt-4o | `AI_PROVIDER=openai` |
| Anthropic | claude-3-5-sonnet | `AI_PROVIDER=anthropic` |
| Mock (no key) | rule-based | `AI_PROVIDER=mock` |

---

## 🏪 Supported POS Adapters

| POS | Status |
|-----|--------|
| Mock Terminal | ✅ Ready |
| Square | ✅ Ready (needs API key) |
| Custom REST | ✅ Ready (configurable) |
| Toast | 🔜 Coming soon |
| Clover | 🔜 Coming soon |

---

## License
MIT — fork it, build on it, ship it.
