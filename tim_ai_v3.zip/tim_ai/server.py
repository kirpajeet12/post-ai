"""
server.py
FastAPI server — Twilio webhook receiver.

Endpoints:
  POST /voice   — called when someone dials your Twilio number
  POST /gather  — called with speech transcription after each utterance
  POST /status  — called when call ends (cleanup)

Run:
  python server.py
  # or
  uvicorn server:app --host 0.0.0.0 --port 8000 --reload

For Twilio webhooks to reach you locally, use ngrok:
  ngrok http 8000
  # then set webhook URL in Twilio console to your ngrok URL
"""

from fastapi import FastAPI, Form, Request, Response
from fastapi.responses import PlainTextResponse
from contextlib import asynccontextmanager
import uvicorn

from config import settings
from ai_engine.llm import get_ai_client
from pos_adapters.factory import get_pos_adapter
from telephony.twilio_handler import (
    handle_incoming_call,
    handle_gather,
    end_session,
)


# ── Shared instances (initialized at startup) ──────────
ai_client = None
pos_adapter = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global ai_client, pos_adapter
    ai_client = get_ai_client()
    pos_adapter = get_pos_adapter()
    print(f"✅  AI Provider  : {settings.AI_PROVIDER}")
    print(f"✅  POS Adapter  : {settings.POS_ADAPTER}")
    print(f"✅  Server ready : {settings.BASE_URL}")
    yield


app = FastAPI(
    title="TIM AI — Voice Order Engine",
    description="AI-powered drive-thru and phone order system",
    version="1.0.0",
    lifespan=lifespan,
)


# ── Health check ───────────────────────────────────────
@app.get("/")
async def health():
    return {
        "status": "running",
        "ai_provider": settings.AI_PROVIDER,
        "pos_adapter": settings.POS_ADAPTER,
    }


# ── Twilio: Incoming call ──────────────────────────────
@app.post("/voice")
async def voice_webhook(
    CallSid: str = Form(...),
    From: str = Form(default="unknown"),
):
    """Called when someone dials your Twilio number."""
    twiml = handle_incoming_call(
        call_sid=CallSid,
        base_url=settings.BASE_URL,
    )
    return Response(content=twiml, media_type="application/xml")


# ── Twilio: Speech gathered ────────────────────────────
@app.post("/gather")
async def gather_webhook(
    CallSid: str = Form(...),
    SpeechResult: str = Form(default=""),
    From: str = Form(default="unknown"),
    timeout: str = Form(default="0"),
):
    """Called with the caller's transcribed speech."""
    twiml = handle_gather(
        call_sid=CallSid,
        speech_result=SpeechResult,
        base_url=settings.BASE_URL,
        ai_client=ai_client,
        pos_adapter=pos_adapter,
    )
    return Response(content=twiml, media_type="application/xml")


# ── Twilio: Call status update ─────────────────────────
@app.post("/status")
async def status_webhook(
    CallSid: str = Form(...),
    CallStatus: str = Form(default=""),
):
    """Called when call ends — clean up session."""
    if CallStatus in ("completed", "failed", "busy", "no-answer", "canceled"):
        end_session(CallSid)
    return PlainTextResponse("OK")


# ── Entry point ────────────────────────────────────────
if __name__ == "__main__":
    uvicorn.run(
        "server:app",
        host="0.0.0.0",
        port=settings.PORT,
        reload=True,
    )
