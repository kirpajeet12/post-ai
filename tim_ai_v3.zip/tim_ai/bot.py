#!/usr/bin/env python3
"""
bot.py — Universal AI ordering bot.
Run setup first: python setup_wizard.py
Then run:        python bot.py

Works for any restaurant/business configured in .env + menu_custom.json
"""

import os
import sys
import json

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# ── Check setup has been run ──────────────────────────────────
if not os.path.exists(".env"):
    print("\n  ⚠️   No config found. Run setup first:\n")
    print("       python setup_wizard.py\n")
    sys.exit(1)

from config.settings import (
    AI_PROVIDER, OPENAI_API_KEY, ANTHROPIC_API_KEY, POS_ADAPTER
)

# Read business config directly from .env
def read_env(key, default=""):
    with open(".env") as f:
        for line in f:
            if line.startswith(key + "="):
                return line.split("=", 1)[1].strip()
    return default

BUSINESS_NAME = read_env("BUSINESS_NAME", "Our Restaurant")
GREETING_MSG  = read_env("GREETING_MSG",  f"Hi! Welcome to {BUSINESS_NAME}. What can I get for you?")
MENU_FILE     = read_env("MENU_FILE",     "menu_custom.json")


# ── Load menu ─────────────────────────────────────────────────
def load_menu():
    """Load menu from custom JSON file or fall back to built-in."""
    if MENU_FILE == "core/menu.py" or not os.path.exists(MENU_FILE):
        # Use built-in Tim Hortons demo menu
        from core.menu import MENU
        return MENU

    with open(MENU_FILE) as f:
        data = json.load(f)

    if not data:
        print("  ⚠️   Menu is empty. Run: python setup_wizard.py → 'Just update the menu'")
        from core.menu import MENU
        return MENU

    return data


# ── Dynamic menu matching ──────────────────────────────────────
def get_aliases_from_menu(menu: dict):
    """Build (canonical_name, alias) list from any menu dict."""
    pairs = []
    for canonical, data in menu.items():
        if isinstance(data, dict):
            for alias in data.get("aliases", [canonical]):
                pairs.append((canonical, alias.lower()))
        else:
            pairs.append((canonical, canonical.lower()))
    return sorted(pairs, key=lambda x: len(x[1]), reverse=True)


def parse_order(text: str, menu: dict):
    """Universal parser — works with any menu."""
    from parser.parser import normalize, detect_size, detect_qty, detect_modifiers, _SPLIT_PATTERN

    chunks = _SPLIT_PATTERN.split(normalize(text))
    items  = []

    aliases = get_aliases_from_menu(menu)

    for chunk in chunks:
        chunk = chunk.strip()
        if not chunk:
            continue

        matched = None
        for canonical, alias in aliases:
            if alias in chunk:
                matched = canonical
                break

        # Coffee presets fallback
        if not matched and any(p in chunk for p in ["double double", "triple triple"]):
            # Find a coffee-type item in the menu
            for name in menu:
                if "coffee" in name:
                    matched = name
                    break

        if not matched:
            continue

        item_data = menu.get(matched, {})
        qty  = detect_qty(chunk)
        size = detect_size(chunk)
        mods = detect_modifiers(chunk, matched) if isinstance(item_data, dict) else []

        if isinstance(item_data, dict) and item_data.get("sizes") and not size:
            size = "medium"

        from core.order import LineItem
        items.append(LineItem(name=matched, qty=qty, size=size, modifiers=mods))

    return items


# ── Colors ────────────────────────────────────────────────────
def c(text, color):
    codes = {"green": "\033[92m", "yellow": "\033[93m", "cyan": "\033[96m",
             "bold": "\033[1m", "reset": "\033[0m", "dim": "\033[2m", "red": "\033[91m"}
    return f"{codes.get(color,'')}{text}{codes['reset']}"

def ai_say(msg):   print(f"\n  🤖  {c('AI:', 'cyan')} {msg}")
def you_say():     return input(f"\n  👤  {c('YOU:', 'bold')} ").strip()


# ── AI conversation (if key provided) ─────────────────────────
def get_ai_response(history, system_prompt, ai_client):
    try:
        return ai_client.chat(history, system=system_prompt)
    except Exception:
        return None


# ── Main bot loop ─────────────────────────────────────────────
def run():
    menu = load_menu()

    # Build system prompt dynamically from business name + menu
    menu_summary = ", ".join(list(menu.keys())[:20])
    system_prompt = f"""You are an ordering assistant for {BUSINESS_NAME}.
Take orders accurately. Keep replies SHORT (1-2 sentences max).
Menu includes: {menu_summary}.
Never make up items not on the menu.
When customer seems done, summarize their order and ask them to confirm."""

    # Load AI client
    ai_client = None
    try:
        from ai_engine.llm import get_ai_client
        ai_client = get_ai_client()
        if AI_PROVIDER != "mock":
            ai_mode = c(f"AI: {AI_PROVIDER}", "green")
        else:
            ai_mode = c("AI: rule-based (no key)", "yellow")
    except Exception:
        ai_mode = c("AI: rule-based fallback", "yellow")

    # POS
    from pos_adapters.factory import get_pos_adapter
    pos = get_pos_adapter()

    # Engine
    from core.engine import OrderEngine, ConversationState
    engine = OrderEngine()

    # Header
    print(f"""
{c('═'*60, 'cyan')}
  {c(BUSINESS_NAME, 'bold')} — AI Ordering Bot
  {ai_mode}  |  POS: {c(POS_ADAPTER, 'green')}
  Type {c("'menu'", 'cyan')} | {c("'order'", 'cyan')} | {c("'done'", 'cyan')} | {c("'cancel'", 'cyan')} | {c("'quit'", 'cyan')}
{c('═'*60, 'cyan')}
""")

    conversation_history = []
    ai_say(GREETING_MSG)

    while True:
        try:
            text = you_say()
        except (KeyboardInterrupt, EOFError):
            print(f"\n\n  {c('Goodbye!', 'yellow')}\n")
            break

        if not text:
            continue

        t = text.lower().strip()

        # ── Commands ────────────────────────────────────────
        if t == "quit":
            print(f"\n  {c('Goodbye!', 'yellow')}\n")
            break

        if t == "menu":
            print(f"\n{c('  MENU — ' + BUSINESS_NAME, 'bold')}")
            cats = {}
            for name, data in menu.items():
                cat = data.get("category", "items") if isinstance(data, dict) else "items"
                cats.setdefault(cat, []).append(name)
            for cat, items in cats.items():
                print(f"\n  {c(cat.upper().replace('_',' '), 'cyan')}")
                for item in items:
                    price = menu[item].get("base_price", "") if isinstance(menu[item], dict) else ""
                    price_str = f"  ${price:.2f}" if price else ""
                    print(f"    • {item.title()}{c(price_str, 'dim')}")
            continue

        if t == "order":
            print(f"\n  {c('Current order:', 'bold')}\n{engine.order.summary() or c('  (empty)', 'dim')}")
            continue

        if engine.is_cancel(t):
            ai_say(engine.cancel())
            conversation_history = []
            continue

        # ── Confirmation state ───────────────────────────────
        if engine.state == ConversationState.CONFIRMATION:
            if engine.is_yes(t):
                order  = engine.finalize()
                ai_say("Placing your order...")
                result = pos.send_order(order.to_dict())
                if result["success"]:
                    ai_say(f"✅ Order placed! #{result.get('pos_order_id','')}. Thank you!")
                else:
                    ai_say(f"❌ Error: {result['message']}. Please try again.")
                print()
                break

            elif engine.is_no(t):
                engine.state = ConversationState.TAKING_ORDER
                ai_say("No problem — what would you like to change?")
                continue

            else:
                # Try to apply a correction
                items = parse_order(text, menu)
                if items:
                    response = engine.apply_correction(text, parsed_items=items)
                    ai_say(response)
                else:
                    # Ask AI for help
                    if ai_client:
                        conversation_history.append({"role": "user", "content": text})
                        ai_response = get_ai_response(conversation_history, system_prompt, ai_client)
                        if ai_response:
                            conversation_history.append({"role": "assistant", "content": ai_response})
                            ai_say(ai_response)
                            continue
                    ai_say("Say 'yes' to confirm, 'no' to change something, or just tell me what to fix.")
                continue

        # ── Done ────────────────────────────────────────────
        if engine.is_done(t):
            ai_say(engine.confirm_order())
            continue

        # ── Size change ─────────────────────────────────────
        size_response = engine.try_size_change(text)
        if size_response:
            ai_say(size_response)
            continue

        # ── Upsell response ──────────────────────────────────
        if engine.state == ConversationState.UPSELL:
            items = parse_order(text, menu)
            if items:
                ai_say(engine.handle_upsell_response(text, parsed_items=items))
            else:
                ai_say(engine.handle_upsell_response(t))
            continue

        # ── Parse items ──────────────────────────────────────
        items = parse_order(text, menu)

        if items:
            conversation_history.append({"role": "user", "content": text})
            response = engine.add_items(items)
            conversation_history.append({"role": "assistant", "content": response})
            ai_say(response)

        elif ai_client and AI_PROVIDER != "mock":
            # Let the AI handle unknown input conversationally
            conversation_history.append({"role": "user", "content": text})
            ai_response = get_ai_response(conversation_history, system_prompt, ai_client)
            if ai_response:
                conversation_history.append({"role": "assistant", "content": ai_response})
                ai_say(ai_response)
            else:
                ai_say("Sorry, I didn't catch that. What would you like to order?")

        else:
            ai_say(
                f"Sorry, I didn't recognise that. "
                f"Type {c('menu', 'cyan')} to see what's available."
            )


if __name__ == "__main__":
    run()
