#!/usr/bin/env python3
"""
cli.py — Terminal ordering AI.

Usage:
  python cli.py              # rule-based (no API keys)
  python cli.py --use-ai     # real AI (set key in .env)

Commands:
  'menu'    → show full menu
  'order'   → show current order
  'done'    → finalize
  'cancel'  → start over
  'quit'    → exit
"""

import argparse
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.engine import OrderEngine, ConversationState
from core.menu import list_menu_text
from parser.parser import parse_multiple, parse_multiple_with_llm
from pos_adapters.factory import get_pos_adapter


BANNER = """
╔══════════════════════════════════════════════════════╗
║         TIM AI — Terminal Order System               ║
║  Type your order. 'menu' | 'done' | 'cancel'         ║
╚══════════════════════════════════════════════════════╝
"""


def ai_say(msg: str) -> None:
    print(f"\n  🤖  AI: {msg}")


def user_prompt() -> str:
    return input("\n  👤 YOU: ").strip()


def parse_input(text: str, ai_client=None):
    """Return list of LineItems from user text."""
    if ai_client:
        return parse_multiple_with_llm(text, ai_client)
    return parse_multiple(text)


def run(use_ai: bool = False):
    print(BANNER)

    engine   = OrderEngine()
    pos      = get_pos_adapter()
    ai_client = None

    if use_ai:
        from ai_engine.llm import get_ai_client
        ai_client = get_ai_client()
        print(f"  ✅  Using real AI ({type(ai_client).__name__})")
    else:
        print("  ℹ️   Using rule-based parser (run with --use-ai for real AI)")

    print()
    ai_say("Hi there! Welcome to Tim Hortons. What can I get started for you today?")

    while True:
        try:
            text = user_prompt()
        except (KeyboardInterrupt, EOFError):
            print("\n\n  Goodbye!\n")
            break

        if not text:
            continue

        t = text.lower().strip()

        # ── Special commands ────────────────────────────────
        if t == "quit":
            print("\n  Goodbye!\n")
            break

        if t == "menu":
            print(list_menu_text())
            continue

        if t == "order":
            print(f"\n  Current order:\n{engine.order.summary() or '  (empty)'}")
            continue

        # ── Cancel ─────────────────────────────────────────
        if engine.is_cancel(t):
            ai_say(engine.cancel())
            continue

        # ── Confirmation state ──────────────────────────────
        if engine.state == ConversationState.CONFIRMATION:
            if engine.is_yes(t):
                order  = engine.finalize()
                ai_say("Placing your order...")
                result = pos.send_order(order.to_dict())
                if result["success"]:
                    ai_say(f"✅  Order placed! #{result.get('pos_order_id','')}. Thanks and see you at the window!")
                else:
                    ai_say(f"❌  Error: {result['message']}. Please try again or speak to staff.")
                print()
                break
            elif engine.is_no(t):
                engine.state = ConversationState.TAKING_ORDER
                ai_say("No problem — what would you like to change?")
            else:
                ai_say("Please say 'yes' to confirm or 'no' to make changes.")
            continue

        # ── Done / confirm ──────────────────────────────────
        if engine.is_done(t):
            ai_say(engine.confirm_order())
            continue

        # ── Upsell response ─────────────────────────────────
        if engine.state == ConversationState.UPSELL:
            # Check if they said yes+item ("yea 1 double double") or just yes/no
            items = parse_input(text, ai_client)
            if items:
                # They named a specific item → add it (implies yes)
                response = engine.handle_upsell_response(text, parsed_items=items)
            else:
                # Plain yes or no
                response = engine.handle_upsell_response(t)
            ai_say(response)
            continue

        # ── Parse order items ───────────────────────────────
        items = parse_input(text, ai_client)

        if items:
            ai_say(engine.add_items(items))
        else:
            ai_say(
                "Sorry, I didn't catch that. "
                "Try: 'medium double double', 'bacon sandwich', or type 'menu' to see options."
            )


def main():
    parser = argparse.ArgumentParser(description="TIM AI Terminal")
    parser.add_argument("--use-ai", action="store_true", help="Use real AI API")
    args = parser.parse_args()
    run(use_ai=args.use_ai)


if __name__ == "__main__":
    main()
