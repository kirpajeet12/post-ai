"""
tests/test_parser.py — run with: python tests/test_parser.py
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from parser.parser import parse_text, parse_multiple, detect_size, detect_qty
from core.engine import OrderEngine


# ── Single item ───────────────────────────────────────

def test_medium_double_double():
    item = parse_text("medium double double")
    assert item is not None
    assert item.name == "coffee"
    assert item.size == "medium"
    assert "double double" in item.modifiers

def test_double_double_no_size_defaults_medium():
    item = parse_text("double double")
    assert item is not None
    assert item.name == "coffee"
    assert item.size == "medium"   # ← bug fix: should default to medium

def test_bacon_sandwich_with_biscuit():
    item = parse_text("bacon breakfast sandwich on biscuit")
    assert item is not None
    assert item.name == "bacon breakfast sandwich"
    assert "biscuit" in item.modifiers

def test_turkey_bacon_no_sauce():
    item = parse_text("turkey bacon club with no sauce")
    assert item is not None
    assert item.name == "turkey bacon club"
    assert "no sauce" in item.modifiers

def test_iced_capp():
    item = parse_text("large iced capp")
    assert item is not None and item.size == "large"

def test_unknown_item():
    assert parse_text("cheeseburger please") is None

def test_hash_brown_qty():
    item = parse_text("two hash browns")
    assert item is not None and item.qty == 2

def test_detect_size():
    assert detect_size("extra large coffee") == "extra large"
    assert detect_size("xl latte") == "extra large"
    assert detect_size("small iced capp") == "small"
    assert detect_size("coffee") is None

def test_detect_qty():
    assert detect_qty("two coffees") == 2
    assert detect_qty("half dozen donuts") == 6
    assert detect_qty("a bagel") == 1
    assert detect_qty("3 hash browns") == 3


# ── Multi-item parsing  ← the main new tests ─────────

def test_multi_item_double_double_AND_sandwich():
    """The bug from the demo: 'double double and turkey bacon club' must catch BOTH."""
    items = parse_multiple("1 double double and turkey bacon club with no sauce")
    names = [i.name for i in items]
    assert "coffee" in names,           f"Expected coffee, got {names}"
    assert "turkey bacon club" in names, f"Expected turkey bacon club, got {names}"

def test_multi_item_three_items():
    items = parse_multiple("large iced capp, hash brown and a bacon breakfast sandwich")
    names = [i.name for i in items]
    assert "iced capp"               in names
    assert "hash brown"              in names
    assert "bacon breakfast sandwich" in names

def test_multi_item_modifiers_per_item():
    """Modifiers should attach to the right item."""
    items = parse_multiple("medium coffee double double and bacon sandwich on biscuit")
    coffee  = next((i for i in items if i.name == "coffee"), None)
    sandwich = next((i for i in items if i.name == "bacon breakfast sandwich"), None)
    assert coffee   is not None and "double double" in coffee.modifiers
    assert sandwich is not None and "biscuit"       in sandwich.modifiers

def test_multi_item_size_on_first():
    items = parse_multiple("large cold brew and a grilled cheese")
    cold_brew = next((i for i in items if i.name == "cold brew"), None)
    assert cold_brew is not None and cold_brew.size == "large"


# ── Engine ────────────────────────────────────────────

def test_engine_add_multiple():
    engine = OrderEngine()
    items  = parse_multiple("medium double double and turkey bacon club no sauce")
    engine.add_items(items)
    assert len(engine.order.items) == 2

def test_engine_upsell_with_item_in_reply():
    """'yea 1 double double' as upsell reply should ADD the coffee, not just say ok."""
    engine = OrderEngine()
    # Add sandwich → triggers upsell (drink offer)
    sandwich = parse_text("bacon breakfast sandwich")
    engine.add_item(sandwich)
    # Simulate upsell state
    from core.engine import ConversationState
    assert engine.state == ConversationState.UPSELL

    # Reply contains an actual item
    reply_items = parse_multiple("yea 1 double double")
    engine.handle_upsell_response("yea 1 double double", parsed_items=reply_items)
    names = [i.name for i in engine.order.items]
    assert "coffee" in names, f"Coffee should be in order after upsell reply, got {names}"

def test_engine_cancel():
    engine = OrderEngine()
    engine.add_item(parse_text("small latte"))
    engine.cancel()
    assert engine.order.is_empty()

def test_order_to_dict():
    from core.order import Order, LineItem
    order = Order()
    order.add_item(LineItem(name="coffee", qty=1, size="medium", modifiers=["double double"]))
    d = order.to_dict()
    assert d["items"][0]["name"] == "coffee"


# ── Runner ────────────────────────────────────────────

if __name__ == "__main__":
    tests = [
        test_medium_double_double,
        test_double_double_no_size_defaults_medium,
        test_bacon_sandwich_with_biscuit,
        test_turkey_bacon_no_sauce,
        test_iced_capp,
        test_unknown_item,
        test_hash_brown_qty,
        test_detect_size,
        test_detect_qty,
        test_multi_item_double_double_AND_sandwich,
        test_multi_item_three_items,
        test_multi_item_modifiers_per_item,
        test_multi_item_size_on_first,
        test_engine_add_multiple,
        test_engine_upsell_with_item_in_reply,
        test_engine_cancel,
        test_order_to_dict,
    ]
    passed = 0
    for t in tests:
        try:
            t()
            print(f"  ✅  {t.__name__}")
            passed += 1
        except Exception as e:
            print(f"  ❌  {t.__name__}  →  {e}")
    print(f"\n{passed}/{len(tests)} passed")
