"""
pos_adapters/custom_pos.py
Generic REST API POS adapter.
Works with any POS that has a REST API.

Setup in .env:
  POS_ADAPTER=custom
  CUSTOM_POS_BASE_URL=https://your-pos.com
  CUSTOM_POS_API_KEY=your-api-key
  CUSTOM_POS_ORDER_ENDPOINT=/api/orders

The adapter sends a POST to:
  {CUSTOM_POS_BASE_URL}{CUSTOM_POS_ORDER_ENDPOINT}

With a JSON body matching our Order format.
Adapt _transform_order() to match your POS API's expected format.
"""

import requests
from typing import Optional
from pos_adapters.base import BasePOS
from config import settings


class CustomRESTPos(BasePOS):
    """
    Generic REST POS adapter.
    Modify _transform_order() to match your POS API format.
    """

    def __init__(self):
        if not settings.CUSTOM_POS_BASE_URL:
            raise ValueError("CUSTOM_POS_BASE_URL not set in .env")

        self.base_url = settings.CUSTOM_POS_BASE_URL.rstrip("/")
        self.endpoint = settings.CUSTOM_POS_ORDER_ENDPOINT
        self.api_key = settings.CUSTOM_POS_API_KEY

        self.headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}",
        }

    def _transform_order(self, order_dict: dict) -> dict:
        """
        ⚙️  CUSTOMIZE THIS METHOD to match your POS API's expected JSON format.

        Default: sends our order format directly.
        Change this to reshape the data however your POS expects it.

        Example for a fictional POS:
        return {
            "external_id": order_dict["id"],
            "order_lines": [
                {
                    "sku": item["name"],
                    "count": item["qty"],
                    "options": item["modifiers"],
                }
                for item in order_dict["items"]
            ]
        }
        """
        return order_dict  # Default: pass-through

    def send_order(self, order_dict: dict) -> dict:
        """POST transformed order to POS endpoint."""
        url = f"{self.base_url}{self.endpoint}"
        payload = self._transform_order(order_dict)

        try:
            response = requests.post(
                url,
                json=payload,
                headers=self.headers,
                timeout=10,
            )

            if response.status_code in (200, 201):
                data = response.json() if response.content else {}
                pos_order_id = data.get("id") or data.get("order_id") or data.get("orderId")
                return {
                    "success": True,
                    "pos_order_id": str(pos_order_id) if pos_order_id else None,
                    "message": "Order sent successfully",
                    "raw_response": data,
                }
            else:
                return {
                    "success": False,
                    "pos_order_id": None,
                    "message": f"POS returned HTTP {response.status_code}: {response.text[:200]}",
                    "raw_response": None,
                }

        except requests.RequestException as e:
            return {
                "success": False,
                "pos_order_id": None,
                "message": f"Network error contacting POS: {str(e)}",
                "raw_response": None,
            }

    def check_availability(self, item_name: str) -> bool:
        """
        Optional: check availability via your POS inventory endpoint.
        Override this if your POS has an inventory API.
        """
        return True

    def get_wait_time(self) -> Optional[int]:
        """Override if your POS exposes a wait time endpoint."""
        return None
