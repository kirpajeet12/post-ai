"""
pos_adapters/square_pos.py
Square POS integration using Square Orders API.

Setup:
1. Create account at developer.squareup.com
2. Get Access Token and Location ID
3. Set in .env:
   POS_ADAPTER=square
   SQUARE_ACCESS_TOKEN=EAAAxxxxx
   SQUARE_LOCATION_ID=Lxxxxxxxx
"""

import uuid
import requests
from typing import Optional
from pos_adapters.base import BasePOS
from config import settings
from core.menu import get_item


SQUARE_API_BASE = "https://connect.squareup.com/v2"
# For sandbox testing:
# SQUARE_API_BASE = "https://connect.squareupsandbox.com/v2"


class SquarePOS(BasePOS):
    """
    Sends orders to Square POS via Orders API.
    Maps menu items to Square catalog item IDs.
    """

    def __init__(self):
        if not settings.SQUARE_ACCESS_TOKEN:
            raise ValueError("SQUARE_ACCESS_TOKEN not set in .env")
        if not settings.SQUARE_LOCATION_ID:
            raise ValueError("SQUARE_LOCATION_ID not set in .env")

        self.headers = {
            "Authorization": f"Bearer {settings.SQUARE_ACCESS_TOKEN}",
            "Content-Type": "application/json",
            "Square-Version": "2024-01-18",
        }
        self.location_id = settings.SQUARE_LOCATION_ID

    def _build_line_items(self, items: list) -> list:
        """
        Convert our LineItem format to Square line items.
        You must map your menu item pos_item_id to Square catalog variation IDs.
        """
        square_items = []

        for item in items:
            menu_data = get_item(item["name"])
            # You need to map pos_item_id → Square catalog_object_id
            # Set these in your Square dashboard and update core/menu.py
            catalog_variation_id = menu_data.get("square_variation_id") if menu_data else None

            line_item = {
                "quantity": str(item["qty"]),
                "name": item["name"].title(),
                "note": ", ".join(item.get("modifiers", [])) or None,
            }

            if catalog_variation_id:
                line_item["catalog_object_id"] = catalog_variation_id
            else:
                # Fallback: manual price (you set base_price in menu.py)
                price_cents = int((menu_data.get("base_price", 0) if menu_data else 0) * 100)
                line_item["base_price_money"] = {
                    "amount": price_cents,
                    "currency": "CAD",
                }

            square_items.append(line_item)

        return square_items

    def send_order(self, order_dict: dict) -> dict:
        """Send order to Square via Orders API."""
        idempotency_key = str(uuid.uuid4())

        payload = {
            "idempotency_key": idempotency_key,
            "order": {
                "location_id": self.location_id,
                "reference_id": order_dict.get("id", ""),
                "line_items": self._build_line_items(order_dict.get("items", [])),
                "source": {
                    "name": "TIM AI Voice System",
                },
            },
        }

        try:
            response = requests.post(
                f"{SQUARE_API_BASE}/orders",
                json=payload,
                headers=self.headers,
                timeout=10,
            )
            data = response.json()

            if response.status_code == 200:
                square_order_id = data.get("order", {}).get("id", "")
                return {
                    "success": True,
                    "pos_order_id": square_order_id,
                    "message": "Order created in Square",
                    "raw_response": data,
                }
            else:
                errors = data.get("errors", [])
                error_msg = errors[0].get("detail", "Unknown error") if errors else str(data)
                return {
                    "success": False,
                    "pos_order_id": None,
                    "message": f"Square error: {error_msg}",
                    "raw_response": data,
                }

        except requests.RequestException as e:
            return {
                "success": False,
                "pos_order_id": None,
                "message": f"Network error: {str(e)}",
                "raw_response": None,
            }

    def check_availability(self, item_name: str) -> bool:
        """
        Check item availability via Square Inventory API.
        Simplified version — extend as needed.
        """
        # TODO: implement Square inventory check
        # For now, assume all items available
        return True

    def get_wait_time(self) -> Optional[int]:
        """Square doesn't provide wait time natively — integrate with Freshdesk or custom."""
        return None
