"""
core/engine.py
Order state machine — drives the conversation flow.

Key fixes v2:
  - add_items() handles a list of items (multi-item sentences)
  - handle_upsell_response() checks if the reply CONTAINS a new order item
    (e.g. "yea 1 double double" → add coffee, not just "ok noted")
  - Size clarification prompt when caller says something vague like "coffee"
"""

from enum import Enum
from typing import Optional, List
from core.order import Order, LineItem
from core.menu import get_item, is_available


class ConversationState(str, Enum):
    GREETING      = "greeting"
    TAKING_ORDER  = "taking_order"
    UPSELL        = "upsell"
    CONFIRMATION  = "confirmation"
    COMPLETE      = "complete"
    CANCELLED     = "cancelled"


DONE_PHRASES = {
    "that's all", "thats all", "that is all", "done", "nothing else",
    "no thanks", "no thank you", "i'm good", "im good", "finish",
    "complete", "place order", "confirm", "that'll be all", "thatll be all",
}

CANCEL_PHRASES = {
    "cancel", "start over", "reset", "never mind", "nevermind",
}

YES_PHRASES = {"yes", "y", "yeah", "yep", "sure", "ok", "okay", "please", "yup", "yea", "ya"}
NO_PHRASES  = {"no", "n", "nope", "nah", "no thanks", "no thank you"}


class OrderEngine:
    """
    Drives the ordering conversation.
    Receives parsed LineItems, manages state, generates response text.
    """

    def __init__(self):
        self.order = Order()
        self.state = ConversationState.GREETING
        self._pending_upsell: Optional[str] = None

    # ── Intent Detection ─────────────────────────────────

    def is_done(self, text: str) -> bool:
        return text.strip().lower() in DONE_PHRASES

    def is_cancel(self, text: str) -> bool:
        return text.strip().lower() in CANCEL_PHRASES

    def is_yes(self, text: str) -> bool:
        return text.strip().lower() in YES_PHRASES

    def is_no(self, text: str) -> bool:
        return text.strip().lower() in NO_PHRASES

    # ── Multi-Item Add ───────────────────────────────────

    def add_items(self, items: List[LineItem]) -> str:
        """
        Add a list of items (from a multi-item sentence like "X and Y").
        Returns a single AI response covering all items.
        """
        if not items:
            return "Sorry, I didn't catch any items. What can I get you?"

        if len(items) == 1:
            return self.add_item(items[0])

        # Multiple items — add them all, then check upsell once at the end
        added_names = []
        unavailable = []

        for item in items:
            if not is_available(item.name):
                unavailable.append(item.name)
                continue
            self.order.add_item(item)
            added_names.append(item.display())

        self.state = ConversationState.TAKING_ORDER

        response_parts = []
        if added_names:
            response_parts.append(f"Got it — {', '.join(added_names)}.")
        if unavailable:
            response_parts.append(
                f"Sorry, {', '.join(unavailable)} isn't available right now."
            )

        # Single upsell check based on last added item
        if self.order.items:
            upsell = self._check_upsell(self.order.items[-1])
            if upsell:
                self._pending_upsell = upsell
                self.state = ConversationState.UPSELL
                response_parts.append(upsell)
                return " ".join(response_parts)

        response_parts.append("Anything else for you?")
        return " ".join(response_parts)

    def add_item(self, item: LineItem) -> str:
        """Add a single item. Returns AI response string."""
        if not is_available(item.name):
            return (
                f"Sorry, {item.name} isn't available right now. "
                "Can I get you something else?"
            )

        self.order.add_item(item)
        self.state = ConversationState.TAKING_ORDER

        upsell = self._check_upsell(item)
        if upsell:
            self._pending_upsell = upsell
            self.state = ConversationState.UPSELL
            return f"Got it — {item.display()}. {upsell}"

        return f"Got it — {item.display()}. Anything else for you?"

    # ── Upsell ───────────────────────────────────────────

    def handle_upsell_response(self, text: str, parsed_items: List[LineItem] = None) -> str:
        """
        Handle the response to an upsell offer.

        Smart logic:
          "yes"                → accept the upsell offer
          "no"                 → decline
          "yea 1 double double" → they said yes AND named a specific item → add that item
          "large iced capp"    → they're ordering a specific drink instead
        """
        self._pending_upsell = None
        self.state = ConversationState.TAKING_ORDER

        # If the parser found actual items in their response, add those
        if parsed_items:
            return self.add_items(parsed_items)

        if self.is_yes(text):
            # Generic yes — add the upsell item if it was a simple one
            if self._last_upsell_item:
                self.order.add_item(LineItem(name=self._last_upsell_item, qty=1))
                self._last_upsell_item = None
                return "Added. Anything else for you?"
            return "Sure! What drink would you like — medium coffee, iced capp, or something else?"

        return "No problem. Anything else for you?"

    # ── Confirmation ─────────────────────────────────────

    def confirm_order(self) -> str:
        self.state = ConversationState.CONFIRMATION
        if self.order.is_empty():
            self.state = ConversationState.TAKING_ORDER
            return "I don't have anything in your order yet. What can I get you?"

        summary = self.order.summary()
        return (
            f"Just to confirm, you have:\n{summary}\n\n"
            "Does that look right? Say 'yes' to place it or 'no' to make changes."
        )

    def finalize(self) -> Order:
        from core.order import OrderStatus
        self.order.status = OrderStatus.CONFIRMED
        self.state = ConversationState.COMPLETE
        return self.order

    def cancel(self) -> str:
        self.order = Order()
        self.state = ConversationState.GREETING
        return "Order cancelled. Let's start fresh — what can I get you?"

    # ── Upsell Rules ─────────────────────────────────────

    _last_upsell_item: Optional[str] = None  # track what we offered

    def _check_upsell(self, item: LineItem) -> Optional[str]:
        """
        Returns an upsell prompt if applicable, else None.
        Only upsells ONCE — if the item was already added or offered, skip.
        """
        drink_categories = {"hot_beverages", "cold_beverages"}

        def has_drink() -> bool:
            return any(
                get_item(i.name) and get_item(i.name).get("category") in drink_categories
                for i in self.order.items
            )

        def has_hash() -> bool:
            return any(i.name == "hash brown" for i in self.order.items)

        breakfast_items = {
            "bacon breakfast sandwich",
            "sausage breakfast sandwich",
            "farmer's wrap",
        }

        # Offer hash brown with breakfast sandwich
        if item.name in breakfast_items and not has_hash():
            self._last_upsell_item = "hash brown"
            return "Would you like to add a hash brown for $1.99?"

        # Offer a drink if they have food but no drink
        item_cat = get_item(item.name) and get_item(item.name).get("category")
        if item_cat not in drink_categories and not has_drink():
            # Don't upsell a drink if they just declined one
            return "Can I get you a drink with that? Medium coffee, iced capp, or anything else?"

        return None
