"""
core/order.py
Data models for orders. Pure Python — no dependencies.
"""

from dataclasses import dataclass, field
from typing import List, Optional
from enum import Enum
import uuid
from datetime import datetime


class OrderStatus(str, Enum):
    OPEN = "open"
    CONFIRMED = "confirmed"
    SENT_TO_POS = "sent_to_pos"
    FAILED = "failed"


@dataclass
class LineItem:
    name: str
    qty: int = 1
    size: Optional[str] = None
    modifiers: List[str] = field(default_factory=list)
    unit_price: Optional[float] = None  # filled by POS after confirmation

    def display(self) -> str:
        parts = [f"{self.qty}x"]
        if self.size:
            parts.append(self.size.title())
        parts.append(self.name.title())
        if self.modifiers:
            parts.append(f"({', '.join(self.modifiers)})")
        return " ".join(parts)

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "qty": self.qty,
            "size": self.size,
            "modifiers": self.modifiers,
            "unit_price": self.unit_price,
        }


@dataclass
class Order:
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8].upper())
    items: List[LineItem] = field(default_factory=list)
    status: OrderStatus = OrderStatus.OPEN
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    customer_phone: Optional[str] = None
    pos_order_id: Optional[str] = None   # returned by POS after sending

    def add_item(self, item: LineItem) -> None:
        self.items.append(item)

    def remove_last_item(self) -> Optional[LineItem]:
        if self.items:
            return self.items.pop()
        return None

    def is_empty(self) -> bool:
        return len(self.items) == 0

    def summary(self) -> str:
        if self.is_empty():
            return "No items in order."
        lines = [f"  - {item.display()}" for item in self.items]
        return "\n".join(lines)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "status": self.status.value,
            "created_at": self.created_at,
            "customer_phone": self.customer_phone,
            "items": [item.to_dict() for item in self.items],
        }
