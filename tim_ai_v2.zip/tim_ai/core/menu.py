"""
core/menu.py
Menu database — structured for AI parsing and POS mapping.
Edit this file to match your actual restaurant menu.
"""

from typing import Dict, List, Optional


# ─────────────────────────────────────────────────────────
# MENU STRUCTURE
# Each item has:
#   aliases       → phrases the AI recognizes
#   sizes         → allowed sizes (None = no size)
#   modifiers     → allowed add-ons / changes
#   base_price    → used by mock POS (real POS overrides this)
#   pos_item_id   → your POS system's internal item ID
# ─────────────────────────────────────────────────────────

MENU: Dict[str, dict] = {

    # ── HOT BEVERAGES ────────────────────────────────────
    "coffee": {
        "category": "hot_beverages",
        "aliases": ["coffee", "regular coffee", "tim's coffee"],
        "sizes": ["small", "medium", "large", "extra large"],
        "modifiers": [
            "black", "double double", "triple triple",
            "1 sugar", "2 sugar", "3 sugar",
            "milk", "cream", "oat milk", "almond milk", "skim milk",
            "espresso shot",
        ],
        "base_price": 2.09,
        "pos_item_id": "COFFEE_001",
    },

    "latte": {
        "category": "hot_beverages",
        "aliases": ["latte", "café latte"],
        "sizes": ["small", "medium", "large"],
        "modifiers": ["oat milk", "almond milk", "skim milk", "sweetener", "extra shot"],
        "base_price": 3.99,
        "pos_item_id": "LATTE_001",
    },

    "cappuccino": {
        "category": "hot_beverages",
        "aliases": ["cappuccino", "cap"],
        "sizes": ["small", "medium", "large"],
        "modifiers": ["oat milk", "sweetener"],
        "base_price": 3.99,
        "pos_item_id": "CAPP_001",
    },

    "french vanilla": {
        "category": "hot_beverages",
        "aliases": ["french vanilla", "vanilla latte", "vanilla coffee"],
        "sizes": ["small", "medium", "large"],
        "modifiers": ["sweetener", "extra shot"],
        "base_price": 3.49,
        "pos_item_id": "FV_001",
    },

    "hot chocolate": {
        "category": "hot_beverages",
        "aliases": ["hot chocolate", "hot choc"],
        "sizes": ["small", "medium", "large"],
        "modifiers": ["whipped cream", "oat milk"],
        "base_price": 2.89,
        "pos_item_id": "HOTCHOC_001",
    },

    # ── COLD BEVERAGES ───────────────────────────────────
    "iced coffee": {
        "category": "cold_beverages",
        "aliases": ["iced coffee", "ice coffee"],
        "sizes": ["small", "medium", "large"],
        "modifiers": ["cream", "sweetener", "extra shot"],
        "base_price": 2.89,
        "pos_item_id": "ICEDCOFFEE_001",
    },

    "iced capp": {
        "category": "cold_beverages",
        "aliases": ["iced capp", "ice capp", "iced cappuccino"],
        "sizes": ["small", "medium", "large"],
        "modifiers": ["whipped cream"],
        "base_price": 3.49,
        "pos_item_id": "ICEDCAPP_001",
    },

    "cold brew": {
        "category": "cold_beverages",
        "aliases": ["cold brew"],
        "sizes": ["small", "medium", "large"],
        "modifiers": ["milk", "sweetener"],
        "base_price": 3.69,
        "pos_item_id": "COLDBREW_001",
    },

    "iced latte": {
        "category": "cold_beverages",
        "aliases": ["iced latte", "ice latte"],
        "sizes": ["small", "medium", "large"],
        "modifiers": ["oat milk", "almond milk", "sweetener", "extra shot"],
        "base_price": 4.29,
        "pos_item_id": "ICEDLATTE_001",
    },

    # ── DONUTS ───────────────────────────────────────────
    "boston cream": {
        "category": "donuts",
        "aliases": ["boston cream", "boston"],
        "sizes": None,
        "modifiers": [],
        "base_price": 1.49,
        "pos_item_id": "DONUT_BC",
    },

    "honey cruller": {
        "category": "donuts",
        "aliases": ["honey cruller", "cruller"],
        "sizes": None,
        "modifiers": [],
        "base_price": 1.49,
        "pos_item_id": "DONUT_HC",
    },

    "chocolate dip": {
        "category": "donuts",
        "aliases": ["chocolate dip", "choc dip"],
        "sizes": None,
        "modifiers": [],
        "base_price": 1.49,
        "pos_item_id": "DONUT_CD",
    },

    "apple fritter": {
        "category": "donuts",
        "aliases": ["apple fritter", "fritter"],
        "sizes": None,
        "modifiers": [],
        "base_price": 1.79,
        "pos_item_id": "DONUT_AF",
    },

    "sour cream glazed": {
        "category": "donuts",
        "aliases": ["sour cream glazed", "sour cream donut"],
        "sizes": None,
        "modifiers": [],
        "base_price": 1.49,
        "pos_item_id": "DONUT_SCG",
    },

    # ── BREAKFAST ────────────────────────────────────────
    "bacon breakfast sandwich": {
        "category": "breakfast",
        "aliases": ["bacon breakfast sandwich", "bacon sandwich", "bacon biscuit"],
        "sizes": None,
        "modifiers": ["english muffin", "biscuit", "bagel", "add egg", "no sauce", "extra cheese"],
        "base_price": 4.99,
        "pos_item_id": "BFAST_BACON",
    },

    "sausage breakfast sandwich": {
        "category": "breakfast",
        "aliases": ["sausage breakfast sandwich", "sausage sandwich", "sausage biscuit"],
        "sizes": None,
        "modifiers": ["english muffin", "biscuit", "bagel", "add egg", "no sauce", "extra cheese"],
        "base_price": 4.99,
        "pos_item_id": "BFAST_SAUS",
    },

    "farmer's wrap": {
        "category": "breakfast",
        "aliases": ["farmer's wrap", "farmers wrap", "farmer wrap"],
        "sizes": None,
        "modifiers": ["no sauce", "extra cheese"],
        "base_price": 5.49,
        "pos_item_id": "BFAST_WRAP",
    },

    "hash brown": {
        "category": "breakfast",
        "aliases": ["hash brown", "hashbrown"],
        "sizes": None,
        "modifiers": [],
        "base_price": 1.99,
        "pos_item_id": "BFAST_HB",
    },

    "bagel": {
        "category": "breakfast",
        "aliases": ["bagel"],
        "sizes": None,
        "modifiers": ["plain", "everything", "sesame", "cream cheese", "butter"],
        "base_price": 2.29,
        "pos_item_id": "BFAST_BAGEL",
    },

    # ── LUNCH ────────────────────────────────────────────
    "grilled cheese": {
        "category": "lunch",
        "aliases": ["grilled cheese"],
        "sizes": None,
        "modifiers": ["extra cheese"],
        "base_price": 3.99,
        "pos_item_id": "LUNCH_GC",
    },

    "chicken wrap": {
        "category": "lunch",
        "aliases": ["chicken wrap"],
        "sizes": None,
        "modifiers": ["no sauce"],
        "base_price": 6.49,
        "pos_item_id": "LUNCH_CW",
    },

    "turkey bacon club": {
        "category": "lunch",
        "aliases": ["turkey bacon club", "tbc"],
        "sizes": None,
        "modifiers": ["no sauce"],
        "base_price": 7.49,
        "pos_item_id": "LUNCH_TBC",
    },

    "chili": {
        "category": "lunch",
        "aliases": ["chili", "bowl of chili"],
        "sizes": ["small", "large"],
        "modifiers": [],
        "base_price": 4.49,
        "pos_item_id": "LUNCH_CHILI",
    },
}


def get_item(name: str) -> Optional[dict]:
    """Return menu item by canonical name."""
    return MENU.get(name)


def get_all_aliases() -> List[tuple]:
    """Return list of (canonical_name, alias) pairs sorted by alias length descending."""
    pairs = []
    for canonical, data in MENU.items():
        for alias in data.get("aliases", []):
            pairs.append((canonical, alias))
    return sorted(pairs, key=lambda x: len(x[1]), reverse=True)


def is_available(item_name: str) -> bool:
    """
    Hook: check if an item is currently available.
    In production, this calls POS inventory API.
    Override this function with a live inventory check.
    """
    return item_name in MENU


def list_menu_text() -> str:
    """Human-readable menu listing."""
    categories: Dict[str, List[str]] = {}
    for name, data in MENU.items():
        cat = data["category"]
        categories.setdefault(cat, []).append(name.title())

    lines = []
    for cat, items in categories.items():
        lines.append(f"\n{cat.upper().replace('_', ' ')}")
        for item in items:
            lines.append(f"  - {item}")
    return "\n".join(lines)
