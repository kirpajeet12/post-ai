"""
ai_engine/llm.py
Unified AI client — OpenAI, Anthropic (Claude), or Mock.
Controlled by AI_PROVIDER in .env

Usage:
    from ai_engine.llm import get_ai_client
    ai = get_ai_client()
    response = ai.chat(history, system_prompt)
"""

from typing import List, Dict, Optional
from config import settings


SYSTEM_PROMPT = """You are TIM AI, a friendly and efficient drive-thru / phone order assistant for a coffee shop.

Your job:
1. Greet the customer warmly
2. Take their order accurately
3. Suggest combos or add-ons naturally (once per order, not pushy)
4. Confirm the full order before finalizing
5. Be fast — keep responses SHORT and conversational

Rules:
- NEVER make up items not on the menu
- If you don't understand, ask ONE clarifying question
- Keep responses under 2 sentences unless confirming order
- Do not explain yourself — just act like a real employee
- Speak naturally, not like a robot

When the customer seems done ordering, summarize their order clearly and ask if it looks right.
"""


class AIClient:
    """Abstract base — all providers implement chat()"""

    def chat(self, messages: List[Dict], system: Optional[str] = None) -> str:
        raise NotImplementedError

    def complete(self, system: str, user: str, max_tokens: int = 300) -> str:
        """One-shot completion (used by parser)."""
        return self.chat(
            messages=[{"role": "user", "content": user}],
            system=system,
        )


# ─────────────────────────────────────────────
# OPENAI
# ─────────────────────────────────────────────

class OpenAIClient(AIClient):
    def __init__(self):
        try:
            from openai import OpenAI
            self.client = OpenAI(api_key=settings.OPENAI_API_KEY)
            self.model = "gpt-4o"
        except ImportError:
            raise ImportError("Run: pip install openai")

    def chat(self, messages: List[Dict], system: Optional[str] = None) -> str:
        full_messages = []
        if system:
            full_messages.append({"role": "system", "content": system})
        full_messages.extend(messages)

        response = self.client.chat.completions.create(
            model=self.model,
            messages=full_messages,
            max_tokens=300,
            temperature=0.4,
        )
        return response.choices[0].message.content.strip()


# ─────────────────────────────────────────────
# ANTHROPIC (Claude)
# ─────────────────────────────────────────────

class AnthropicClient(AIClient):
    def __init__(self):
        try:
            import anthropic
            self.client = anthropic.Anthropic(api_key=settings.ANTHROPIC_API_KEY)
            self.model = "claude-sonnet-4-6"
        except ImportError:
            raise ImportError("Run: pip install anthropic")

    def chat(self, messages: List[Dict], system: Optional[str] = None) -> str:
        kwargs = {
            "model": self.model,
            "max_tokens": 300,
            "messages": messages,
        }
        if system:
            kwargs["system"] = system

        response = self.client.messages.create(**kwargs)
        return response.content[0].text.strip()


# ─────────────────────────────────────────────
# MOCK (no API key needed)
# ─────────────────────────────────────────────

class MockAIClient(AIClient):
    """
    Rule-based mock AI for testing without API keys.
    Follows a simple script.
    """

    def __init__(self):
        self._turn = 0

    def chat(self, messages: List[Dict], system: Optional[str] = None) -> str:
        self._turn += 1
        last_user = messages[-1]["content"].lower() if messages else ""

        # Detect done intent
        done_words = ["that's all", "done", "nothing", "no thanks", "confirm"]
        if any(w in last_user for w in done_words):
            return "Got it. Let me confirm your order — please say 'yes' to finalize."

        # Generic fallback
        return "Got it. What else can I get for you?"

    def complete(self, system: str, user: str, max_tokens: int = 300) -> str:
        """Mock parser — returns null item (falls back to rule-based)."""
        return '{"item": null}'


# ─────────────────────────────────────────────
# FACTORY
# ─────────────────────────────────────────────

def get_ai_client() -> AIClient:
    """
    Returns AI client based on AI_PROVIDER in .env
    """
    provider = settings.AI_PROVIDER.lower()

    if provider == "openai":
        if not settings.OPENAI_API_KEY:
            print("⚠️  OPENAI_API_KEY not set — falling back to mock AI")
            return MockAIClient()
        return OpenAIClient()

    elif provider == "anthropic":
        if not settings.ANTHROPIC_API_KEY:
            print("⚠️  ANTHROPIC_API_KEY not set — falling back to mock AI")
            return MockAIClient()
        return AnthropicClient()

    else:
        return MockAIClient()
