"""
tests/test_parser.py
Basic tests — run with: python -m pytest tests/ -v
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from parser.parser import parse_text, detect_size, detect_qty
from core.engine import OrderEngine


# ── Parser tests ──────────────────────────────────────

def test_medium_double_double():
    item = parse_text("medium double double")
    assert item is not None
    assert item.name == "coffee"
    assert item.size == "medium"
    assert "double double" in item.modifiers


def test_bacon_sandwich_with_biscuit():
    item = parse_text("bacon breakfast sandwich on biscuit")
    assert item is not None
    assert item.name == "bacon breakfast sandwich"
    assert "biscuit" in item.modifiers


def test_iced_capp():
    item = parse_text("large iced capp")
    assert item is not None
    assert item.name == "iced capp"
    assert item.size == "large"


def test_unknown_item():
    item = parse_text("give me a cheeseburger")
    assert item is None


def test_hash_brown():
    item = parse_text("two hash browns")
    assert item is not None
    assert item.name == "hash brown"
    assert item.qty == 2


def test_quantity_word():
    item = parse_text("three coffees")
    assert item is not None
    assert item.qty == 3


def test_detect_size():
    assert detect_size("extra large coffee") == "extra large"
    assert detect_size("xl latte") == "extra large"
    assert detect_size("small iced capp") == "small"
    assert detect_size("coffee") is None


def test_detect_qty():
    assert detect_qty("two coffees") == 2
    assert detect_qty("half dozen donuts") == 6
    assert detect_qty("a bagel") == 1
    assert detect_qty("3 hash browns") == 3


# ── Engine tests ──────────────────────────────────────

def test_engine_add_and_confirm():
    engine = OrderEngine()
    from parser.parser import parse_text
    item = parse_text("medium coffee double double")
    assert item is not None
    engine.add_item(item)
    assert not engine.order.is_empty()
    confirmation = engine.confirm_order()
    assert "coffee" in confirmation.lower()


def test_engine_cancel():
    engine = OrderEngine()
    from parser.parser import parse_text
    item = parse_text("small latte")
    engine.add_item(item)
    engine.cancel()
    assert engine.order.is_empty()


def test_order_to_dict():
    from core.order import Order, LineItem
    order = Order()
    order.add_item(LineItem(name="coffee", qty=1, size="medium", modifiers=["double double"]))
    d = order.to_dict()
    assert d["items"][0]["name"] == "coffee"
    assert d["items"][0]["size"] == "medium"


if __name__ == "__main__":
    # Run manually without pytest
    tests = [
        test_medium_double_double,
        test_bacon_sandwich_with_biscuit,
        test_iced_capp,
        test_unknown_item,
        test_hash_brown,
        test_quantity_word,
        test_detect_size,
        test_detect_qty,
        test_engine_add_and_confirm,
        test_engine_cancel,
        test_order_to_dict,
    ]
    passed = 0
    for t in tests:
        try:
            t()
            print(f"  ✅  {t.__name__}")
            passed += 1
        except AssertionError as e:
            print(f"  ❌  {t.__name__} FAILED: {e}")
    print(f"\n{passed}/{len(tests)} passed")
