"""
core/engine.py
Order state machine — drives the conversation flow.
Handles upsells, confirmations, error recovery.
"""

from enum import Enum
from typing import Optional
from core.order import Order, LineItem
from core.menu import get_item, is_available


class ConversationState(str, Enum):
    GREETING = "greeting"
    TAKING_ORDER = "taking_order"
    MODIFIERS = "modifiers"
    UPSELL = "upsell"
    CONFIRMATION = "confirmation"
    COMPLETE = "complete"
    CANCELLED = "cancelled"


DONE_PHRASES = {
    "that's all", "thats all", "that is all", "done", "nothing else",
    "no thanks", "no thank you", "i'm good", "im good", "finish",
    "complete", "place order", "confirm",
}

CANCEL_PHRASES = {
    "cancel", "start over", "reset", "never mind", "nevermind",
}

YES_PHRASES = {"yes", "y", "yeah", "yep", "sure", "ok", "okay", "please", "yup"}
NO_PHRASES = {"no", "n", "nope", "nah", "no thanks", "no thank you"}


class OrderEngine:
    """
    Drives the ordering conversation.
    Receives parsed LineItems, manages state, generates AI prompts.
    """

    def __init__(self):
        self.order = Order()
        self.state = ConversationState.GREETING
        self._pending_upsell: Optional[str] = None  # item name pending upsell offer

    # ── Intent Detection ─────────────────────────────────

    def is_done(self, text: str) -> bool:
        return text.strip().lower() in DONE_PHRASES

    def is_cancel(self, text: str) -> bool:
        return text.strip().lower() in CANCEL_PHRASES

    def is_yes(self, text: str) -> bool:
        return text.strip().lower() in YES_PHRASES

    def is_no(self, text: str) -> bool:
        return text.strip().lower() in NO_PHRASES

    # ── Item Handling ────────────────────────────────────

    def add_item(self, item: LineItem) -> str:
        """
        Add item to order. Returns AI response string.
        Checks availability. Triggers upsell if applicable.
        """
        if not is_available(item.name):
            return (
                f"Sorry, {item.name} isn't available right now. "
                "Can I get you something else?"
            )

        self.order.add_item(item)
        self.state = ConversationState.TAKING_ORDER

        # Check for upsell opportunities
        upsell = self._check_upsell(item)
        if upsell:
            self._pending_upsell = upsell
            self.state = ConversationState.UPSELL
            return f"Got it — {item.display()}. {upsell}"

        return f"Got it — {item.display()}. Anything else for you?"

    def handle_upsell_response(self, text: str) -> str:
        """Handle yes/no response to an upsell offer."""
        self._pending_upsell = None
        self.state = ConversationState.TAKING_ORDER

        if self.is_yes(text):
            # Add the upsell item automatically
            if "hash brown" in (self._pending_upsell or ""):
                self.order.add_item(LineItem(name="hash brown", qty=1))
                return "Hash brown added. Would you also like a drink with that?"
            return "Awesome — added. Anything else for you?"

        return "No problem. Anything else for you?"

    def confirm_order(self) -> str:
        """Build confirmation message."""
        self.state = ConversationState.CONFIRMATION
        if self.order.is_empty():
            self.state = ConversationState.TAKING_ORDER
            return "I don't have anything in your order yet. What would you like?"

        summary = self.order.summary()
        return (
            f"Just to confirm, you have:\n{summary}\n\n"
            "Does that all look right? Say 'yes' to place the order or 'no' to make changes."
        )

    def finalize(self) -> Order:
        """Mark order as confirmed and return it."""
        from core.order import OrderStatus
        self.order.status = OrderStatus.CONFIRMED
        self.state = ConversationState.COMPLETE
        return self.order

    def cancel(self) -> str:
        """Reset everything."""
        self.order = Order()
        self.state = ConversationState.GREETING
        return "Order cancelled. Let's start over — what can I get you?"

    # ── Upsell Logic ─────────────────────────────────────

    def _check_upsell(self, item: LineItem) -> Optional[str]:
        """
        Returns an upsell prompt string if applicable, else None.
        Add more upsell rules here.
        """
        breakfast_items = {
            "bacon breakfast sandwich",
            "sausage breakfast sandwich",
            "farmer's wrap",
        }

        # Offer combo if they ordered breakfast without hash brown
        if item.name in breakfast_items:
            has_hash = any(i.name == "hash brown" for i in self.order.items)
            has_drink = any(
                get_item(i.name) and get_item(i.name).get("category") in ("hot_beverages", "cold_beverages")
                for i in self.order.items
            )
            if not has_hash:
                return "Would you like to add a hash brown for $1.99?"

        # Offer a drink if no drink yet
        drink_categories = {"hot_beverages", "cold_beverages"}
        has_drink = any(
            get_item(i.name) and get_item(i.name).get("category") in drink_categories
            for i in self.order.items
        )
        if not has_drink and item.name not in {"coffee", "latte", "iced capp", "iced coffee", "cold brew"}:
            return "Can I get you a drink with that? A medium coffee or iced capp?"

        return None
