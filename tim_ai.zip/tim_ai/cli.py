#!/usr/bin/env python3
"""
cli.py
Terminal-based ordering AI — no Twilio needed.
Perfect for development, demos, and testing.

Usage:
  python cli.py              # rule-based AI (no API keys)
  python cli.py --use-ai     # real AI (needs key in .env)

Commands during ordering:
  'done'       → finalize order
  'cancel'     → start over
  'menu'       → show menu
  'quit'       → exit
"""

import argparse
import sys
import os

# Ensure project root is on path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.engine import OrderEngine, ConversationState
from core.menu import list_menu_text
from parser.parser import parse_text, parse_text_with_llm
from pos_adapters.factory import get_pos_adapter


BANNER = """
╔══════════════════════════════════════════════════════╗
║         TIM AI — Terminal Order System               ║
║  Type your order. 'menu' | 'done' | 'cancel'         ║
╚══════════════════════════════════════════════════════╝
"""


def ai_say(msg: str) -> None:
    print(f"\n  🤖  AI: {msg}")


def user_prompt() -> str:
    return input("\n  👤 YOU: ").strip()


def run(use_ai: bool = False):
    print(BANNER)

    # Initialize components
    engine = OrderEngine()
    pos = get_pos_adapter()

    ai_client = None
    if use_ai:
        from ai_engine.llm import get_ai_client
        ai_client = get_ai_client()
        print(f"  ✅  Using real AI ({type(ai_client).__name__})")
    else:
        print("  ℹ️   Using rule-based parser (run with --use-ai for real AI)")

    print()

    # Greeting
    ai_say("Hi there! Welcome to Tim Hortons. What can I get started for you today?")

    while True:
        try:
            text = user_prompt()
        except (KeyboardInterrupt, EOFError):
            print("\n\nExiting. Bye!")
            break

        if not text:
            continue

        t = text.lower().strip()

        # ── Special commands ────────────────────────────
        if t == "quit":
            print("\n  Goodbye!\n")
            break

        if t == "menu":
            print(list_menu_text())
            continue

        if t == "order":
            print(f"\n  Current order:\n{engine.order.summary() or '  (empty)'}")
            continue

        # ── Cancel ──────────────────────────────────────
        if engine.is_cancel(t):
            response = engine.cancel()
            ai_say(response)
            continue

        # ── Confirmation state ───────────────────────────
        if engine.state == ConversationState.CONFIRMATION:
            if engine.is_yes(t):
                order = engine.finalize()
                ai_say("Placing your order...")
                result = pos.send_order(order.to_dict())

                if result["success"]:
                    order_id = result.get("pos_order_id", "")
                    ai_say(
                        f"✅  Order placed! Order #{order_id}. "
                        "Thanks and see you at the window!"
                    )
                else:
                    ai_say(
                        f"❌  Something went wrong: {result['message']}. "
                        "Please try again or speak to staff."
                    )
                print()
                break

            elif engine.is_no(t):
                engine.state = ConversationState.TAKING_ORDER
                ai_say("No problem — what would you like to change?")
                continue
            else:
                ai_say("Please say 'yes' to confirm or 'no' to make changes.")
                continue

        # ── Done / confirm ────────────────────────────────
        if engine.is_done(t):
            if engine.order.is_empty():
                ai_say("You don't have anything in your order yet. What can I get you?")
                continue
            confirmation = engine.confirm_order()
            ai_say(confirmation)
            continue

        # ── Upsell response ───────────────────────────────
        if engine.state == ConversationState.UPSELL:
            response = engine.handle_upsell_response(t)
            ai_say(response)
            continue

        # ── Parse item ────────────────────────────────────
        item = None
        if ai_client:
            item = parse_text_with_llm(text, ai_client)
        if not item:
            item = parse_text(text)

        if item:
            response = engine.add_item(item)
            ai_say(response)
        else:
            ai_say(
                "Sorry, I didn't catch that. "
                "Try something like 'medium double double' or 'bacon breakfast sandwich'."
            )


def main():
    parser = argparse.ArgumentParser(description="TIM AI Terminal Order System")
    parser.add_argument(
        "--use-ai",
        action="store_true",
        help="Use real AI API (set AI_PROVIDER + key in .env)",
    )
    args = parser.parse_args()
    run(use_ai=args.use_ai)


if __name__ == "__main__":
    main()
