"""
pos_adapters/mock_pos.py
Simulates a POS system in the terminal.
No API keys needed — perfect for development and demos.
"""

import uuid
from pos_adapters.base import BasePOS


class MockPOS(BasePOS):
    """
    Prints orders to terminal and returns fake success.
    Use this for local testing.
    """

    def send_order(self, order_dict: dict) -> dict:
        fake_order_id = f"MOCK-{str(uuid.uuid4())[:6].upper()}"

        print("\n" + "="*50)
        print("📦  ORDER SENT TO POS (MOCK)")
        print("="*50)
        print(f"  Order ID  : {fake_order_id}")
        print(f"  Customer  : {order_dict.get('customer_phone', 'walk-in')}")
        print(f"  Items ({len(order_dict.get('items', []))}):")
        for item in order_dict.get("items", []):
            size = f"[{item['size']}] " if item.get("size") else ""
            mods = f" — {', '.join(item['modifiers'])}" if item.get("modifiers") else ""
            print(f"    • {item['qty']}x {size}{item['name']}{mods}")
        print("="*50)
        print("  ✅  Mock POS accepted order")
        print("="*50 + "\n")

        return {
            "success": True,
            "pos_order_id": fake_order_id,
            "message": "Order accepted by mock POS",
            "raw_response": order_dict,
        }

    def check_availability(self, item_name: str) -> bool:
        # Mock: everything is available
        return True

    def get_wait_time(self) -> int:
        return 5  # Mock: always 5 minutes
