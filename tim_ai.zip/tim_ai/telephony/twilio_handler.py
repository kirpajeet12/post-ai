"""
telephony/twilio_handler.py
Handles incoming Twilio calls.

Flow:
  1. Twilio calls your /voice endpoint (POST)
  2. We return TwiML (XML) telling Twilio what to say
  3. Twilio plays it to the caller
  4. Caller speaks → Twilio transcribes → POST to /gather
  5. We process → return next TwiML

Session state is stored in memory by call SID.
For production: use Redis or a database for session storage.
"""

from typing import Dict
from core.order import Order
from core.engine import OrderEngine, ConversationState


# In-memory session store keyed by Twilio CallSid
_sessions: Dict[str, OrderEngine] = {}


def get_or_create_session(call_sid: str) -> OrderEngine:
    """Get existing session or create a new one for this call."""
    if call_sid not in _sessions:
        _sessions[call_sid] = OrderEngine()
    return _sessions[call_sid]


def end_session(call_sid: str) -> None:
    """Clean up session when call ends."""
    _sessions.pop(call_sid, None)


def twiml_say_and_gather(
    message: str,
    action_url: str,
    voice: str = "Polly.Joanna",
    language: str = "en-CA",
    timeout: int = 5,
) -> str:
    """
    Returns TwiML XML that:
    1. Speaks a message (text-to-speech)
    2. Records the caller's response (speech input)
    3. POSTs transcription to action_url
    """
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Gather input="speech" action="{action_url}" method="POST"
          speechTimeout="auto" timeout="{timeout}" language="{language}">
    <Say voice="{voice}">{message}</Say>
  </Gather>
  <Redirect method="POST">{action_url}?timeout=1</Redirect>
</Response>"""


def twiml_say_and_hang_up(message: str, voice: str = "Polly.Joanna") -> str:
    """Returns TwiML that speaks a message and hangs up."""
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="{voice}">{message}</Say>
  <Hangup/>
</Response>"""


def twiml_redirect(url: str) -> str:
    """Redirects call to another URL."""
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Redirect method="POST">{url}</Redirect>
</Response>"""


def handle_incoming_call(call_sid: str, base_url: str) -> str:
    """
    Handler for the initial /voice webhook.
    Called when a new call comes in.
    """
    engine = get_or_create_session(call_sid)
    engine.state = ConversationState.GREETING

    greeting = (
        "Hi there! Welcome to Tim Hortons. "
        "What can I get started for you today?"
    )
    return twiml_say_and_gather(
        message=greeting,
        action_url=f"{base_url}/gather",
    )


def handle_gather(
    call_sid: str,
    speech_result: str,
    base_url: str,
    ai_client,
    pos_adapter,
) -> str:
    """
    Handler for /gather webhook — processes what the caller said.

    Args:
        call_sid: Twilio call SID
        speech_result: Transcribed speech from caller
        base_url: Your server's public URL
        ai_client: AI client instance
        pos_adapter: POS adapter instance

    Returns:
        TwiML XML string
    """
    engine = get_or_create_session(call_sid)

    # Handle timeout (empty speech)
    if not speech_result or speech_result.strip() == "":
        return twiml_say_and_gather(
            message="Sorry, I didn't catch that. What can I get you?",
            action_url=f"{base_url}/gather",
        )

    text = speech_result.strip()

    # ── Cancel ───────────────────────────────
    if engine.is_cancel(text):
        response = engine.cancel()
        return twiml_say_and_gather(response, f"{base_url}/gather")

    # ── Confirmation state ───────────────────
    if engine.state == ConversationState.CONFIRMATION:
        if engine.is_yes(text):
            order = engine.finalize()
            result = pos_adapter.send_order(order.to_dict())

            end_session(call_sid)

            if result["success"]:
                order_id = result.get("pos_order_id", "")
                msg = (
                    f"Perfect! Your order has been placed. "
                    f"Order number {order_id}. "
                    "See you at the window. Thank you!"
                )
            else:
                msg = (
                    "I'm sorry, there was an issue placing your order. "
                    "Please pull forward and a team member will help you. Thank you!"
                )
            return twiml_say_and_hang_up(msg)

        elif engine.is_no(text):
            engine.state = ConversationState.TAKING_ORDER
            return twiml_say_and_gather(
                "No problem — what would you like to change?",
                f"{base_url}/gather",
            )

    # ── Done / wants to confirm ──────────────
    if engine.is_done(text):
        if engine.order.is_empty():
            return twiml_say_and_gather(
                "I don't have anything in your order yet. What can I get you?",
                f"{base_url}/gather",
            )
        confirmation = engine.confirm_order()
        return twiml_say_and_gather(confirmation, f"{base_url}/gather")

    # ── Upsell response ──────────────────────
    if engine.state == ConversationState.UPSELL:
        response = engine.handle_upsell_response(text)
        return twiml_say_and_gather(response, f"{base_url}/gather")

    # ── Parse order item ─────────────────────
    try:
        from parser.parser import parse_text_with_llm, parse_text
        # Try LLM first, fallback to rule-based
        item = parse_text_with_llm(text, ai_client)
        if not item:
            item = parse_text(text)
    except Exception:
        from parser.parser import parse_text
        item = parse_text(text)

    if item:
        response = engine.add_item(item)
        return twiml_say_and_gather(response, f"{base_url}/gather")

    # ── Fallback: ask AI for conversational response ──
    try:
        history = [{"role": "user", "content": text}]
        ai_response = ai_client.chat(history, system=None)
        return twiml_say_and_gather(ai_response, f"{base_url}/gather")
    except Exception:
        return twiml_say_and_gather(
            "Sorry, I didn't understand that. Can you say your order again?",
            f"{base_url}/gather",
        )
