"""
parser/parser.py
Converts raw user text → structured LineItem.
Two modes:
  1. Rule-based (no API key needed, works offline)
  2. LLM-assisted (more accurate, requires ai_engine)
"""

import re
from typing import Optional
from core.order import LineItem
from core.menu import get_all_aliases, get_item


# ─────────────────────────────────────────────
# RULE-BASED PARSER
# ─────────────────────────────────────────────

SIZE_WORDS = ["extra large", "large", "medium", "small"]
SIZE_ALIASES = {"xl": "extra large", "xlarge": "extra large", "sm": "small", "lg": "large", "md": "medium"}

COFFEE_PRESETS = {
    "double double": "double double",
    "triple triple": "triple triple",
    "black": "black",
}


def normalize(text: str) -> str:
    return re.sub(r"\s+", " ", text.strip().lower())


def detect_size(text: str) -> Optional[str]:
    t = normalize(text)
    for alias, canonical in SIZE_ALIASES.items():
        if re.search(rf"\b{alias}\b", t):
            return canonical
    for size in SIZE_WORDS:
        if size in t:
            return size
    return None


def detect_qty(text: str) -> int:
    t = normalize(text)
    # "half dozen"
    if "half dozen" in t:
        return 6
    m = re.search(r"\b(\d+)\b", t)
    if m:
        return max(1, int(m.group(1)))
    word_map = {
        "a": 1, "an": 1, "one": 1, "two": 2, "three": 3,
        "four": 4, "five": 5, "six": 6, "dozen": 12,
    }
    for w, n in word_map.items():
        if re.search(rf"\b{w}\b", t):
            return n
    return 1


def detect_modifiers(text: str, item_name: str) -> list:
    """Extract modifiers relevant to this item from user text."""
    t = normalize(text)
    mods = []

    item_data = get_item(item_name)
    if not item_data:
        return mods

    allowed = [m.lower() for m in item_data.get("modifiers", [])]

    # Coffee presets
    for phrase, mod in COFFEE_PRESETS.items():
        if phrase in t and mod in allowed:
            mods.append(mod)

    # Sugar count
    sugar_match = re.search(r"\b(\d)\s*sugar(s)?\b", t)
    if sugar_match:
        mod = f"{sugar_match.group(1)} sugar"
        if mod in allowed:
            mods.append(mod)

    # Check each allowed modifier
    for mod in allowed:
        if mod not in mods and mod in t:
            mods.append(mod)

    return mods


def parse_text(text: str) -> Optional[LineItem]:
    """
    Rule-based parser.
    Returns LineItem or None if no menu item found.
    """
    t = normalize(text)

    # Find best matching menu item
    aliases = get_all_aliases()
    matched_name = None
    for canonical, alias in aliases:
        if alias in t:
            matched_name = canonical
            break

    # "double double" / "triple triple" without "coffee" still means coffee
    if not matched_name:
        if any(p in t for p in ["double double", "triple triple"]):
            matched_name = "coffee"
        else:
            return None

    qty = detect_qty(t)
    size = detect_size(t)
    mods = detect_modifiers(t, matched_name)

    # Default size for beverages
    item_data = get_item(matched_name)
    if item_data and item_data.get("sizes") and not size:
        size = "medium"  # sensible default

    return LineItem(name=matched_name, qty=qty, size=size, modifiers=mods)


# ─────────────────────────────────────────────
# LLM-ASSISTED PARSER
# ─────────────────────────────────────────────

PARSE_SYSTEM_PROMPT = """You are an order parsing assistant for a coffee shop.
Extract the order from the customer's message and return ONLY valid JSON.

JSON format:
{
  "item": "<canonical item name>",
  "qty": <integer>,
  "size": "<small|medium|large|extra large|null>",
  "modifiers": ["<mod1>", "<mod2>"]
}

Known items: {menu_items}

Rules:
- "double double" means 2 cream 2 sugar (modifier)
- Default size is medium for drinks
- Return null for size if item has no size
- Return empty array if no modifiers
- If you cannot identify an item, return: {"item": null}
"""


def parse_text_with_llm(text: str, ai_client) -> Optional[LineItem]:
    """
    LLM-assisted parser. Uses ai_engine to extract structured order.
    Falls back to rule-based if LLM fails.
    """
    import json
    from core.menu import MENU

    menu_items = ", ".join(MENU.keys())
    system = PARSE_SYSTEM_PROMPT.format(menu_items=menu_items)

    try:
        response = ai_client.complete(
            system=system,
            user=text,
            max_tokens=200,
        )

        # Strip markdown code fences if present
        raw = response.strip()
        if raw.startswith("```"):
            raw = re.sub(r"```[a-zA-Z]*\n?", "", raw).strip("`").strip()

        data = json.loads(raw)

        if not data.get("item"):
            return None

        return LineItem(
            name=data["item"],
            qty=int(data.get("qty", 1)),
            size=data.get("size"),
            modifiers=data.get("modifiers", []),
        )

    except Exception:
        # Fallback to rule-based
        return parse_text(text)
